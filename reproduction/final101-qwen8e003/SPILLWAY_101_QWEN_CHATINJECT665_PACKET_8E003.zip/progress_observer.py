"""Read-only progress observation; never starts/retries/changes a model call."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta, timezone

try:
    from zoneinfo import ZoneInfo
    PACIFIC = ZoneInfo("America/Los_Angeles")
except Exception:  # console clock label only
    PACIFIC = None


class ProgressObserver:
    def __init__(self, root, drive_root, owner_dir, settings, protocol, *, interval=10):
        self.root = Path(root).resolve()
        self.owner_dir = Path(owner_dir)
        self.settings = dict(settings)
        self.state = Path("/content") / ("spw_final014_" + protocol["artifact"]["wheel_sha256"][:12])
        self.records = Path(drive_root) / "results" / settings["run_id"] / settings["dispatch"] / str(settings["worker_id"])
        self.cells = protocol["dispatches"][settings["dispatch"]]["workers"][str(settings["worker_id"])]
        self.interval = interval
        self.stage = "preparing"
        self.stage_details = {}
        self.errors = []
        self.child = None
        self.stop = threading.Event()
        self.guard = threading.RLock()
        self.raw_cache = {}
        self.judge_cache = {}
        self.thread = None
        self.lane_started = None
        self.lane_done_at_start = 0
        self.last_printed = None
        self.last_printed_key = None
        self.judge_errors_printed = 0

    def _error(self, error):
        with self.guard:
            self.errors.append(type(error).__name__)
        print("[SPILLWAY observation warning] " + type(error).__name__, flush=True)

    def set_stage(self, stage, **details):
        with self.guard:
            self.stage, self.stage_details = stage, details
        print("[SPILLWAY stage] " + stage + " " + json.dumps(details, sort_keys=True), flush=True)

    def start(self):
        self.thread = threading.Thread(target=self._loop, name="spillway-observer", daemon=True)
        self.thread.start()

    def _file(self, path):
        try:
            info = path.stat()
            return {"path": str(path), "bytes": info.st_size, "mtime_ns": info.st_mtime_ns}
        except FileNotFoundError:
            return {"path": str(path), "bytes": 0, "present": False}

    def _judge(self, path, cell_id, judge):
        """Read-only summary of one cell's judge_requests.jsonl, with the closure's own failure rule."""
        try:
            info = path.stat()
        except FileNotFoundError:
            return
        signature = (info.st_size, info.st_mtime_ns)
        cached = self.judge_cache.get(str(path))
        if cached is None or cached[0] != signature:
            requests, errors, slowest, last = 0, 0, None, None
            for line in path.read_text().splitlines():
                try:
                    row = json.loads(line)
                except ValueError:
                    continue
                requests += 1
                latency, duration = row.get("latency_s"), (row.get("usage") or {}).get("total_duration")
                seconds = latency if isinstance(latency, (int, float)) else (
                    duration / 1e9 if isinstance(duration, (int, float)) else None)
                if seconds is not None and (slowest is None or seconds > slowest):
                    slowest = seconds
                if row.get("error_type") or row.get("http_status") != 200:
                    errors += 1
                    last = (row.get("error_type") or "HTTP " + str(row.get("http_status")), seconds)
            cached = (signature, requests, errors, slowest, last)
            self.judge_cache[str(path)] = cached
        _, requests, errors, slowest, last = cached
        judge["requests"] += requests
        judge["errors"] += errors
        if slowest is not None and (judge["slowest_s"] is None or slowest > judge["slowest_s"]):
            judge["slowest_s"] = round(slowest, 1)
        if last is not None:
            judge.update(last_error_cell=cell_id, last_error_type=last[0],
                         last_error_latency_s=None if last[1] is None else round(last[1], 1))

    def snapshot(self):
        with self.guard:
            stage, details, errors = self.stage, dict(self.stage_details), list(self.errors)
        watched = [self.state / "ollama-linux-amd64.tar.zst", self.state / "ollama.log"]
        watched.extend(sorted((self.state / "models/blobs").glob("sha256-*")))
        watched.extend(self.owner_dir / n for n in ("preparation_stdout.txt", "preparation_stderr.txt", "stdout.txt", "stderr.txt"))
        counts = {"planned_scored_UIDs": sum(len(c["planned_uids"]) for c in self.cells),
                  "closed_cells": 0, "closed_scored_UIDs": 0,
                  "saved_unclosed_scored_scope_UIDs": 0}
        cell_rows, judge = [], {"requests": 0, "errors": 0, "slowest_s": None}
        for cell in self.cells:
            folder = self.records / "cells" / cell["cell_id"]
            watched.extend(folder / n for n in ("stdout.txt", "stderr.txt", "calls.jsonl", "provider_responses.jsonl"))
            self._judge(folder / "judge_requests.jsonl", cell["cell_id"], judge)
            expected = {(r["user_task_id"], r["injection_task_id"]) for r in cell["planned_uids"]}
            closure = folder / "CELL_CLOSURE.json"
            if closure.is_file():
                try:
                    value = json.loads(closure.read_text())
                    observed = {(r["user_task_id"], r["injection_task_id"]) for r in value.get("planned_uids", [])}
                    if value.get("status") == "EXACT_UID_CELL_COMPLETE" and observed == expected and value.get("score", {}).get("scored") == len(expected):
                        counts["closed_cells"] += 1
                        counts["closed_scored_UIDs"] += len(expected)
                        cell_rows.append({"cell_id": cell["cell_id"], "planned": len(expected),
                                          "saved": len(expected), "closed": True})
                        continue
                except (OSError, ValueError, KeyError, TypeError):
                    pass
            saved = set()
            for path in (folder / "raw").rglob("*.json"):
                try:
                    info = path.stat()
                    signature = (info.st_size, info.st_mtime_ns)
                    cached = self.raw_cache.get(str(path))
                    if cached is None or cached[0] != signature:
                        value = json.loads(path.read_text())
                        key = (value.get("user_task_id"), value.get("injection_task_id")) if isinstance(value, dict) else None
                        valid = isinstance(value, dict) and "messages" in value and isinstance(value.get("utility"), bool) and isinstance(value.get("security"), bool)
                        self.raw_cache[str(path)] = (signature, key if valid else None)
                    key = self.raw_cache[str(path)][1]
                    if key in expected:
                        saved.add(key)
                except (OSError, ValueError, KeyError, TypeError):
                    pass
            counts["saved_unclosed_scored_scope_UIDs"] += len(saved)
            cell_rows.append({"cell_id": cell["cell_id"], "planned": len(expected), "saved": len(saved), "closed": False})
        return {"UTC": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "stage": stage, "details": details, "controller_pid": os.getpid(),
                "child_pid": self.child.pid if self.child is not None else None,
                "child_returncode": self.child.poll() if self.child is not None else None,
                "dispatch": self.settings["dispatch"], "run_id": self.settings["run_id"],
                "counts": counts, "cells_progress": cell_rows,
                "current_cell": next((row for row in cell_rows if not row["closed"]), None), "judge": judge,
                "files": [self._file(p) for p in watched],
                "observation_errors": errors, "partial_UIDs_are_scored": False,
                "observer_additional_model_or_health_API_calls": 0}

    def emit(self):
        try:
            value = self.snapshot()
            path = self.owner_dir / "PREPARATION_HEARTBEAT.json"
            temporary = path.with_name(path.name + ".tmp." + str(os.getpid()))
            temporary.write_text(json.dumps(value, indent=2) + "\n")
            temporary.replace(path)
            with (self.owner_dir / "OBSERVATION.jsonl").open("a") as stream:
                stream.write(json.dumps(value, separators=(",", ":")) + "\n")
            self._print_progress(value)
        except Exception as error:
            self._error(error)

    def _print_progress(self, value):
        """Console only. One line a minute, at once on a stage or cell change, and one ALERT per new judge error."""
        counts, now = value["counts"], time.monotonic()
        planned = counts["planned_scored_UIDs"]
        done = counts["closed_scored_UIDs"] + counts["saved_unclosed_scored_scope_UIDs"]
        if value["stage"] == "original_lane_running" and self.lane_started is None:
            self.lane_started, self.lane_done_at_start = now, done
        judge = value.get("judge") or {}
        if judge.get("errors", 0) > self.judge_errors_printed:
            self.judge_errors_printed = judge["errors"]
            print(f"[SPILLWAY ALERT] judge request failed in {judge.get('last_error_cell')}: "
                  f"{judge.get('last_error_type')} after {judge.get('last_error_latency_s')} s. "
                  "That cell cannot close. The run will stop and keep its records unscored.", flush=True)
        key = (value["stage"], counts["closed_cells"])
        if key == self.last_printed_key and self.last_printed is not None and now - self.last_printed < 60:
            return
        self.last_printed_key, self.last_printed = key, now
        line = (f"[SPILLWAY progress] {value['UTC']} | {value['stage']}"
                f" | cells closed {counts['closed_cells']}/{len(self.cells)}"
                f" | UIDs saved or closed {done}/{planned} ({100.0 * done / max(planned, 1):.1f}%)")
        current = value.get("current_cell")
        if current and self.lane_started is not None:
            line += f" | now {current['cell_id']} {current['saved']}/{current['planned']}"
        if self.lane_started is not None:
            minutes = (now - self.lane_started) / 60.0
            rate = (done - self.lane_done_at_start) / minutes if minutes > 0 else 0.0
            line += f" | lane {minutes:.1f} min"
            if minutes >= 2 and rate > 0 and done < planned:
                left = (planned - done) / rate
                end = datetime.now(timezone.utc) + timedelta(minutes=left)
                clock = end.astimezone(PACIFIC).strftime("%H:%M %Z") if PACIFIC else end.strftime("%H:%M UTC")
                line += f" | {rate:.1f} UIDs/min so far | about {left:.0f} min left, near {clock} (rate so far)"
        else:
            line += f" | watched_bytes={sum(f['bytes'] for f in value['files'])}"
        if judge.get("requests"):
            line += (f" | judge {judge['requests']} calls, {judge.get('errors', 0)} failed,"
                     f" slowest {judge.get('slowest_s')} s (limit 30 s)")
        print(line, flush=True)

    def _loop(self):
        while not self.stop.is_set():
            self.emit()
            self.stop.wait(self.interval)

    def close(self):
        self.stop.set()
        if self.thread is not None:
            self.thread.join(timeout=2)
        # A slow Drive read must never delay/cancel the owned worker cleanup.
        if self.thread is None or not self.thread.is_alive():
            self.emit()

    def run(self, command, *, check=False, **kwargs):
        """Same argv/env/cwd and return-code policy; only tee preparation stdio."""
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kwargs)

        def drain(stream, filename, console):
            log = None
            try:
                log = (self.owner_dir / filename).open("ab")
            except OSError as error:
                self._error(error)
            try:
                while True:
                    block = stream.read1(8192)
                    if not block:
                        break
                    if log is not None:
                        try:
                            log.write(block)
                            log.flush()
                        except OSError as error:
                            self._error(error)
                            log.close()
                            log = None
                    try:
                        console.write(block.decode("utf-8", errors="replace"))
                        console.flush()
                    except Exception as error:
                        self._error(error)
            finally:
                stream.close()
                if log is not None:
                    log.close()

        readers = [threading.Thread(target=drain, args=(process.stdout, "preparation_stdout.txt", sys.stdout), daemon=True),
                   threading.Thread(target=drain, args=(process.stderr, "preparation_stderr.txt", sys.stderr), daemon=True)]
        for reader in readers:
            reader.start()
        try:
            code = process.wait()
        except BaseException:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
            raise
        finally:
            for reader in readers:
                reader.join()
        if check and code:
            raise subprocess.CalledProcessError(code, command)
        return subprocess.CompletedProcess(command, code)
