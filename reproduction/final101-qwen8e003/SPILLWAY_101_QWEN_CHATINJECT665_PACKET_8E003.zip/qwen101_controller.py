"""One newly authorized standard-only Colab lane; no paid credential path."""
from __future__ import annotations

import fcntl
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import tempfile
import time
import uuid


def _stop_owned(process):
    if process is None or process.poll() is not None:
        return
    if os.getpgid(process.pid) != process.pid:
        raise RuntimeError('Refuse to signal a process outside the owned child session')
    os.killpg(process.pid, signal.SIGTERM)
    try:
        process.wait(timeout=15)
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGKILL)
        process.wait(timeout=5)


def run(root, drive_root, *, root_gate_path, run_id):
    root, drive_root = Path(root).resolve(), Path(drive_root).resolve()
    sys.path.insert(0, str(root))
    import runtime as rt
    from common import dump, read, require, sha
    import evaluation_environment
    import model_server

    protocol = read(root / 'PROTOCOL.json')
    dispatch = next(iter(protocol['dispatches']))
    require(len(protocol['dispatches']) == 1, 'Exactly one local standard backbone per VM')
    require(protocol['dispatches'][dispatch]['kind'] == 'local', 'Paid lane is outside this packet')
    require(set(protocol['dispatches'][dispatch]['workers']) == {'0'}, 'One original endpoint lease')
    require(isinstance(run_id, str) and run_id and '/' not in run_id, 'Explicit new run ID required')
    settings = {'run_model': True, 'execution_location': 'Colab', 'dispatch': dispatch,
                'worker_id': '0', 'run_id': run_id, 'paid_api_opt_in': False,
                'root_gate_path': str(Path(root_gate_path).resolve())}
    rt.require_live_ready(root, settings)
    require(sys.version_info[:2] == (3, 13), 'Original current-Python3.13 family required')
    rt.gpu_check(90000, protocol['colab_expected_gpu_tokens'])
    with socket.socket() as probe:
        probe.settimeout(1)
        require(probe.connect_ex(('127.0.0.1', 11489)) != 0,
                'Port11489 occupied; never take over another service')
    lock_path = Path(tempfile.gettempdir()) / 'spillway_101_standard_colab_VM.lock'
    process = None
    server_owner = None
    with lock_path.open('a+') as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        owner_dir = drive_root / 'orchestration' / run_id / dispatch
        owner_dir.mkdir(parents=True, exist_ok=False)
        owner = {'status': 'PREPARING', 'owner_nonce': uuid.uuid4().hex,
                 'controller_pid': os.getpid(), 'dispatch': dispatch,
                 'protocol_sha256': sha(root / 'PROTOCOL.json'),
                 'root_gate_sha256': sha(settings['root_gate_path']),
                 'API_credentials_read': False, 'paid_API_calls_allowed': 0,
                 'started_UTC': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())}
        dump(owner_dir / 'OWNER.json', owner, exclusive=True)
        state = Path('/content') / ('spw_final014_' + protocol['artifact']['wheel_sha256'][:12])
        owner_path = state / 'OLLAMA_OWNER.json'
        before = owner_path.read_bytes() if owner_path.is_file() else None
        from progress_observer import ProgressObserver
        observer = ProgressObserver(root, drive_root, owner_dir, settings, protocol)
        observer.start()
        try:
            observer.set_stage('evaluation_environment_prepare')
            environment = evaluation_environment.prepare(root)
            dump(owner_dir / 'PYTHON_ENVIRONMENT.json', environment, exclusive=True)
            installed = rt.install(root, drive_root, settings, progress=observer)
            dump(owner_dir / 'INSTALL_RECEIPT.json', installed, exclusive=True)
            observer.set_stage('model_preparation')
            server = model_server.prepare(root, installed, settings, progress=observer)
            observer.set_stage('model_preparation_complete')
            require(owner_path.is_file() and owner_path.read_bytes() != before,
                    'Own server receipt missing; no pre-existing owner takeover')
            server_owner = read(owner_path)
            spec = owner_dir / 'LANE.json'
            dump(spec, {'root': str(root), 'drive_root': str(drive_root),
                        'installed': installed, 'server': server, 'settings': settings}, exclusive=True)
            env = dict(os.environ, PYTHONDONTWRITEBYTECODE='1', OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
            env.pop('OPENAI_API_KEY', None)
            with (owner_dir / 'stdout.txt').open('x') as stdout, (owner_dir / 'stderr.txt').open('x') as stderr:
                process = subprocess.Popen([installed['python'], '-B', str(root / 'qwen101_lane.py'), str(spec)],
                                           env=env, stdout=stdout, stderr=stderr, start_new_session=True)
                dump(owner_dir / 'CHILD.json', {'pid': process.pid, 'PGID': process.pid}, exclusive=True)
                observer.child = process
                observer.set_stage('original_lane_running', child_pid=process.pid)
                code = process.wait()
            require(code == 0, 'Original lane failed; preserve partial, no automatic retry')
            observer.set_stage('aggregate_exact_scope')
            from aggregate import aggregate
            result = aggregate(root, drive_root / 'results' / run_id)
            require(result['status'] == 'EXACT_REQUESTED_UID_SCOPE_COMPLETE_REQUIRES_PAPER_ANALYSIS',
                    'Exact original UID closure incomplete; do not score partial scope')
            from native_auxiliary import audit_auxiliary
            auxiliaries = [audit_auxiliary(drive_root / 'results' / run_id / dispatch / '0' / 'cells' / c['cell_id'], c)
                           for c in protocol['dispatches'][dispatch]['workers']['0']]
            expected_auxiliary = sum(len(c['injection_task_ids']) for c in protocol['dispatches'][dispatch]['workers']['0']
                                     if c['attack'] != 'none')
            require(sum(x['count'] for x in auxiliaries) == expected_auxiliary == protocol['native_standalone_episodes'],
                    'Native standalone scope incomplete')
            dump(owner_dir / 'NATIVE_AUXILIARY_MANIFEST.json', auxiliaries, exclusive=True)
            dump(owner_dir / 'AGGREGATE.json', result, exclusive=True)
            dump(owner_dir / 'CLOSURE.json', {**owner, 'status': 'EXACT_DISPATCH_SCOPE_COMPLETE', 'dispatch_scope': dispatch,
                  'ended_UTC': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
                  'actual_API_cost_USD': 0, 'canonical_standalone_audit_pending': False, 'physical_native_standalone_records': expected_auxiliary}, exclusive=True)
            observer.set_stage('exact_dispatch_scope_complete')
            return result
        except BaseException as error:
            observer.set_stage('stopped_preserve_no_autorelaunch', error_type=type(error).__name__)
            dump(owner_dir / 'STOPPED.json', {**owner, 'status': 'STOPPED_PRESERVE_NO_AUTORELAUNCH',
                  'error_type': type(error).__name__, 'partial_is_scored': False}, exclusive=True)
            raise
        finally:
            observer.close()
            _stop_owned(process)
            # Also catch our own server if model preparation failed after spawn.
            if server_owner is None and owner_path.is_file() and owner_path.read_bytes() != before:
                server_owner = read(owner_path)
            if server_owner and owner_path.is_file() and read(owner_path) == server_owner:
                pid = server_owner['pid']
                binary = (state / 'ollama/bin/ollama').resolve()
                try:
                    command = Path(f'/proc/{pid}/cmdline').read_bytes().split(b'\0')
                    if pid > 1 and Path(os.fsdecode(command[0])).resolve() == binary:
                        os.kill(pid, signal.SIGTERM)
                except ProcessLookupError:
                    pass
                except FileNotFoundError:
                    pass
            fcntl.flock(lock, fcntl.LOCK_UN)
