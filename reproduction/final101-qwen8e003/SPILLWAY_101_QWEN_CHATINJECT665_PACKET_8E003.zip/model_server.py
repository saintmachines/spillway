"""Pinned Ollama preparation, callable only after the final semantic gate."""
from __future__ import annotations
import json
import os
from pathlib import Path
import shutil
import socket
import subprocess
import time
import urllib.request
from common import dump, read, require, sha
from runtime import require_live_ready


def fetch_verified(url, destination, digest, size=None, *, progress=None):
    destination = Path(destination)
    destination.parent.mkdir(parents=True, exist_ok=True)
    if not destination.is_file() or (size is not None and destination.stat().st_size != size) or sha(destination) != digest:
        if progress is not None:
            progress.set_stage("download", filename=destination.name, expected_bytes=size)
        run_command = progress.run if progress is not None else subprocess.run
        run_command(["curl", "-fL", "--retry", "5", "-C", "-", "-o", str(destination), url], check=True)
    require((size is None or destination.stat().st_size == size) and sha(destination) == digest, "Downloaded bytes differ: " + destination.name)


def get(url):
    with urllib.request.urlopen(url, timeout=10) as response:
        return json.load(response)



WARMUP_PROMPT_LINES = (7, 13, 19)  # three task-free prompts across the judge's usual length range
WARMUP_STEADY_BOUND_S = 5.0  # root sets this bound. The scored judge timeout stays 30 s.


def _warmup_prompt(lines):
    """Task-free text in the judge's answer shape. No task, tool, user, attack or benchmark content."""
    filler = "".join(f"Note {k}: this line is neutral filler for a warm-up request.\n" for k in range(1, lines + 1))
    return ("This is a warm-up request. It contains no task, tool, user or benchmark content.\n"
            "Decide whether the sentence below is a greeting.\n"
            "Sentence: Good morning, everyone.\n" + filler +
            "- COHERENT (1): the sentence is a greeting.\n"
            "- DEVIATING (0): the sentence is not a greeting.\n\n"
            'Respond JSON only: {"verdict":0|1,"reason":"..."}')


def _is_verdict_json(text):
    try:
        return json.loads(text).get("verdict") in (0, 1)
    except Exception:
        return False


def warm_local_judge(endpoint, protocol, installed, settings, *, progress=None):
    """One task-free preload, then task-free generations with the judge's own request body, outside all
    evaluation/latency ledgers. A load-only request left about 21 s of first-generation cost on Colab (11/17)."""
    import hashlib
    judge = protocol["local_judge"]
    context = protocol["decode"]["judge_context"]
    require(context == 4096, "Frozen judge context changed")
    body = {"model": judge, "prompt": "", "stream": False, "format": "json",
            "think": False,
            "options": {"temperature": 0.0, "num_predict": 200, "num_ctx": context}}
    wire = json.dumps(body).encode("utf-8")
    local = Path(installed["state"]) / "warmup_records" / settings["run_id"] / settings["dispatch"] / str(settings["worker_id"])
    locations = [local]
    if progress is not None and Path(progress.owner_dir).resolve() != local.resolve():
        locations.append(Path(progress.owner_dir))
    for folder in locations:
        folder.mkdir(parents=True, exist_ok=True)
        require(not (folder / "JUDGE_WARMUP_STARTED.json").exists()
                and not (folder / "JUDGE_WARMUP.json").exists(),
                "Warmup already attempted for this owner; preserve it, no automatic retry")
    started = time.monotonic()
    receipt = {"status": "LOCAL_JUDGE_WARMUP_STARTED",
               "started_UTC": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               "model": judge, "expected_model_digest": protocol["models"][judge],
               "request": body, "request_sha256": hashlib.sha256(wire).hexdigest(),
               "request_timeout_s": 600, "generate_requests": 1 + len(WARMUP_PROMPT_LINES), "agent_requests": 0,
               "warmup_generations": len(WARMUP_PROMPT_LINES), "steady_state_bound_s": WARMUP_STEADY_BOUND_S,
               "task_content_used": False, "included_in_evaluation_ledgers": False,
               "included_in_benchmark_latency": False, "scored_episodes": 0,
               "evaluation_reference_timeout_unchanged_s": 30,
               "run_id": settings["run_id"], "dispatch": settings["dispatch"]}
    for folder in locations:
        dump(folder / "JUDGE_WARMUP_STARTED.json", receipt, exclusive=True)
    if progress is not None:
        progress.set_stage("local_judge_cold_load_warmup", model=judge,
                           context=context, timeout_s=600, benchmark_latency=False)
    try:
        request = urllib.request.Request(endpoint.rstrip("/") + "/api/generate", data=wire,
                                         headers={"Content-Type": "application/json"})
        with urllib.request.urlopen(request, timeout=600) as response:
            value = json.loads(response.read().decode("utf-8"))
        receipt["request_latency_s"] = time.monotonic() - started
        require(isinstance(value, dict) and value.get("model") == judge
                and value.get("done") is True, "Warmup response model/completion mismatch")
        receipt["returned"] = {key: value.get(key) for key in
                               ("model", "done", "done_reason", "prompt_eval_count",
                                "eval_count", "load_duration", "total_duration")}
        generations = []
        for lines in WARMUP_PROMPT_LINES:
            generation_body = dict(body, prompt=_warmup_prompt(lines))  # same keys, order and options as the judge
            generation_wire = json.dumps(generation_body).encode("utf-8")
            if progress is not None:
                progress.set_stage("local_judge_generation_warmup", model=judge, generation=len(generations) + 1,
                                   of=len(WARMUP_PROMPT_LINES), benchmark_latency=False)
            began = time.monotonic()
            generation_request = urllib.request.Request(endpoint.rstrip("/") + "/api/generate", data=generation_wire,
                                                        headers={"Content-Type": "application/json"})
            with urllib.request.urlopen(generation_request, timeout=600) as response:
                answer = json.loads(response.read().decode("utf-8"))
            latency = time.monotonic() - began
            require(isinstance(answer, dict) and answer.get("model") == judge and answer.get("done") is True,
                    "Warmup generation model/completion mismatch")
            require(type(answer.get("eval_count")) is int and answer["eval_count"] > 0,
                    "Warmup generation produced no positive integer eval_count; stop before worker")
            generations.append({"request_sha256": hashlib.sha256(generation_wire).hexdigest(),
                                "request_latency_s": latency,
                                "response_is_verdict_json": _is_verdict_json(answer.get("response", "")),
                                **{key: answer.get(key) for key in ("done_reason", "prompt_eval_count", "eval_count",
                                                                    "load_duration", "total_duration")}})
            receipt["generations"] = generations
        receipt["steady_state_latency_s"] = generations[-1]["request_latency_s"]
        require(generations[-1]["request_latency_s"] < WARMUP_STEADY_BOUND_S,
                "Warm judge not at steady state before the lane: stop before the worker, no automatic retry")
        resident = [row for row in get(endpoint.rstrip("/") + "/api/ps").get("models", [])
                    if row.get("name", row.get("model")) == judge]
        require(len(resident) == 1, "Warm judge is not uniquely resident")
        row = resident[0]
        receipt["residency"] = {key: row.get(key) for key in
                                ("name", "model", "digest", "context_length", "size", "size_vram")}
        require(row.get("model", judge) == judge and row.get("digest") == protocol["models"][judge],
                "Warm judge resident model/digest drift")
        require(row.get("context_length") == context, "Warm judge context differs from frozen judge")
        require(type(row.get("size")) is int and row["size"] > 0
                and type(row.get("size_vram")) is int and row["size_vram"] == row["size"],
                "Warm judge is not wholly resident on CUDA; no CPU/partial-offload fallback")
        receipt.update(status="LOCAL_JUDGE_WARMUP_READY", warmup_ready=True,
                       full_CUDA_residency=True, latency_s=time.monotonic() - started,
                       ended_UTC=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
    except BaseException as error:
        receipt.update(status="LOCAL_JUDGE_WARMUP_FAILED_BEFORE_WORKER", warmup_ready=False,
                       error_type=type(error).__name__, latency_s=time.monotonic() - started,
                       ended_UTC=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()))
        for folder in locations:
            dump(folder / "JUDGE_WARMUP.json", receipt, exclusive=True)
        if progress is not None:
            progress.set_stage("local_judge_warmup_failed_before_worker", error_type=type(error).__name__)
        raise
    for folder in locations:
        dump(folder / "JUDGE_WARMUP.json", receipt, exclusive=True)
    if progress is not None:
        progress.set_stage("local_judge_warmup_verified", model=judge, context=context, full_CUDA=True,
                           steady_state_latency_s=receipt["steady_state_latency_s"], benchmark_latency=False)
    return receipt


def prepare(root, installed, settings, *, progress=None):
    root = Path(root).resolve()
    p = require_live_ready(root, settings)
    require(settings["execution_location"] == "Colab", "This pinned server installer is Colab-only")
    state = Path(installed["state"])
    ollama = p["ollama"]
    archive = state / "ollama-linux-amd64.tar.zst"
    fetch_verified(ollama["url"], archive, ollama["sha256"], progress=progress)
    binary = state / "ollama"
    binary.mkdir(exist_ok=True)
    unpack = "import sys,tarfile,zstandard;f=open(sys.argv[1],'rb');z=zstandard.ZstdDecompressor().stream_reader(f);t=tarfile.open(fileobj=z,mode='r|');t.extractall(sys.argv[2],filter='data')"
    if progress is not None:
        progress.set_stage("ollama_archive_unpack")
    run_command = progress.run if progress is not None else subprocess.run
    run_command([installed["python"], "-c", unpack, str(archive), str(binary)], check=True)
    pins = read(root / "model_pins/MODEL_PINS.json")["models"]
    cells = p["dispatches"][settings["dispatch"]]["workers"][str(settings["worker_id"]) ]
    selected = {p["local_judge"]} | {cell["model"] for cell in cells if not cell["model"].startswith("gpt-")}
    context = max([p["model_contexts"][name] for name in selected if name in p["model_contexts"]] or [40960])
    models = state / "models"
    for name in sorted(selected):
        pin = pins[name]
        library, tag = name.split(":")
        manifest = root / "model_pins" / pin["manifest_file"]
        require(sha(manifest) == pin["manifest_sha256"] == p["models"][name], "Model manifest drift")
        target = models / "manifests/registry.ollama.ai/library" / library / tag
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(manifest.read_bytes())
        for layer in pin["layers"]:
            destination = models / "blobs" / ("sha256-" + layer["digest"])
            destination.parent.mkdir(parents=True, exist_ok=True)
            if layer["sidecar_file"]:
                small = root / "model_pins" / layer["sidecar_file"]
                require(sha(small) == layer["digest"], "Small model descriptor drift")
                if not destination.exists():
                    shutil.copyfile(small, destination)
            fetch_verified(layer["url"], destination, layer["digest"], layer["bytes"], progress=progress)
    if progress is not None:
        progress.set_stage("pinned_ollama_server_health_and_digest_check")
    port = 11489
    endpoint = f"http://127.0.0.1:{port}"
    owner_path = state / "OLLAMA_OWNER.json"
    owner_key = {"protocol_sha256": sha(root / "PROTOCOL.json"), "wheel_sha256": p["artifact"]["wheel_sha256"]}
    with socket.socket() as probe:
        probe.settimeout(1)
        listening = probe.connect_ex(("127.0.0.1", port)) == 0
    if listening:
        require(owner_path.is_file() and read(owner_path).get("owner_key") == owner_key, "Unowned/different server: stop; do not take over")
    else:
        env = dict(os.environ, OLLAMA_HOST=f"127.0.0.1:{port}", OLLAMA_MODELS=str(models), OLLAMA_CONTEXT_LENGTH=str(context),
                   OLLAMA_NUM_PARALLEL="1", OLLAMA_FLASH_ATTENTION="true", OLLAMA_KV_CACHE_TYPE="q8_0",
                   OLLAMA_MAX_LOADED_MODELS="2", OLLAMA_KEEP_ALIVE="2h")
        with (state / "ollama.log").open("a") as log:
            proc = subprocess.Popen([str(binary / "bin/ollama"), "serve"], env=env, stdout=log, stderr=log)
        dump(owner_path, {"pid": proc.pid, "owner_key": owner_key})
        deadline = time.monotonic() + 60
        while True:
            try:
                get(endpoint + "/api/version")
                break
            except Exception:
                require(time.monotonic() < deadline, "Own pinned Ollama server failed health probe")
                time.sleep(1)
    require(get(endpoint + "/api/version")["version"] == ollama["version"], "Ollama version drift")
    found = {row["name"]: row["digest"] for row in get(endpoint + "/api/tags")["models"]}
    require(all(found.get(name) == p["models"][name] for name in selected), "Served model digest drift")
    warmup = warm_local_judge(endpoint, p, installed, settings, progress=progress)
    return {"endpoint": endpoint, "models": {name: found[name] for name in selected}, "version": ollama["version"],
            "judge_warmup": warmup}
