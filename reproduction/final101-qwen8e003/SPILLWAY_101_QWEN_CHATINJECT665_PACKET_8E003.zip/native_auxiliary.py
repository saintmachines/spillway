"""Separate native injection-task standalone logs from user-pair scoring.

The original native 0.1.35 benchmark stores standalone injection tasks with
user_task_id=injection_task_N, injection_task_id=None and attack_type=None.
Those logs are retained and audited; they are not attacked user-pair UIDs.
Native AgentDojo writes them for every non-DoS attack (chat_inject, cache_injection and autodojo too).
The 11/15 helper native_aux_overflow.py authorized them for every attack except none; this rule matches it.
All unknown, missing or duplicate user-pair records still fail original closure.
"""
from collections import defaultdict
import json
from pathlib import Path


def auxiliary(record, cell):
    return (cell['attack'] != 'none'
            and record.get('user_task_id') in cell['injection_task_ids']
            and record.get('injection_task_id') is None and record.get('attack_type') is None
            and record.get('suite_name') == cell['suite']
            and record.get('benchmark_version') == 'v1.2.2')


def audit_auxiliary(records, cell):
    from common import require, sha
    found=defaultdict(list)
    for path in (Path(records)/'raw').rglob('*.json'):
        value=json.loads(path.read_text())
        if isinstance(value,dict) and auxiliary(value,cell):
            require(isinstance(value.get('utility'),bool) and isinstance(value.get('security'),bool),
                    'Unscored auxiliary native record')
            error=value.get('error')
            require(error is None or any(s in str(error)for s in ('context_length_exceeded','maximum context length is exceeded')),
                    'Native auxiliary runtime error; retain all records')
            found[value['user_task_id']].append({'path':str(path.relative_to(records)),'sha256':sha(path)})
    expected=set(cell['injection_task_ids'])if cell['attack']!='none'else set()
    require(set(found)==expected and all(len(v)==1 for v in found.values()),
            'Missing/duplicate/foreign native auxiliary task; full scope not closed')
    return {'status':'EXACT_NATIVE_AUXILIARY_UIDS_RETAINED_NOT_USER_ATTACK_DENOMINATOR',
            'suite':cell['suite'],'count':len(found),'records':dict(found),
            'changes_to_native_utility_or_security':False}


def install():
    import closure
    from common import require

    def select_records(records,cell):
        # Original select_records logic, with only the exact declared native
        # standalone representation excluded from the user-pair grouping.
        grouped=defaultdict(list)
        for path in (Path(records)/'raw').rglob('*.json'):
            record=json.loads(path.read_text())
            if isinstance(record,dict)and 'messages'in record and 'user_task_id'in record:
                if auxiliary(record,cell):
                    continue
                grouped[(record['user_task_id'],record.get('injection_task_id'))].append((record,path))
        from common import planned
        wanted={(row['user_task_id'],row['injection_task_id'])for row in planned(cell)}
        require(set(grouped)==wanted and all(len(value)==1 for value in grouped.values()),
                'Missing/foreign/duplicate UID: partial data remain unscored')
        selected={key:value[0]for key,value in grouped.items()}
        for record,_ in selected.values():
            require(record.get('suite_name')==cell['suite']and record.get('benchmark_version')=='v1.2.2','Suite/version drift')
            require(record.get('attack_type')==(None if cell['attack']=='none'else cell['attack']),'Attack field drift')
            require(isinstance(record.get('utility'),bool)and isinstance(record.get('security'),bool),'Unscored/nonboolean record')
            error=record.get('error')
            require(error is None or any(t in str(error)for t in ('context_length_exceeded','maximum context length is exceeded')),
                    'Non-overflow runtime error: preserve partial and stop')
        audit_auxiliary(records,cell)
        return selected
    closure.select_records=select_records
