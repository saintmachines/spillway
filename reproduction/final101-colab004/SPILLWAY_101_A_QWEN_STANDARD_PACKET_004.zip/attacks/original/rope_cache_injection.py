"""cache_injection attack for ROPE's cloned AgentDojo (PISmith adaptive-attack REPLAY).

Modeled on ROPE's clone convention (chat_inject_attacks.py: `@register_attack class ChatInjectAttack(BaseAttack)` whose
`attack()` returns `{inj: block for inj in self.get_injection_candidates(user_task)}`). This class instead reads the
released engine's injection cache (UV2R_CACHE) and replays the cached carrier for each (suite, user_task, injection_task).
No attack is authored here.

Cache format (same as the PISmith cache branch):
  * UV2R_CACHE -> a JSON file: {suite: {user_task: {injection_task: carrier}}}  OR  a list of
    {"suite","user_task","injection_task","carrier"|"carriers"} records.
  * per-defense: if injections_<arm>.json sits next to the shared file it is preferred (UV2R_ARM, "rope" here).
  * carrier may be a single string or a LIST of variants; UV2R_ATTEMPT (default 0) selects variants[attempt % K]. Each
    call appends {attempt, n_variants, ...} to UV2R_STAMP so the aggregator can compute ASR@1 and ASR@10.

INSTALL (build_pisreplay_rope): this file is copied into the ROPE clone at
`/content/ROPE/autodojo/src/agentdojo/attacks/rope_cache_injection.py` and imported (an import line appended to that
package's __init__.py), so `python -m rope.run_eval --attack cache_injection` resolves it in ROPE's own agentdojo.

UNVERIFIED OFFLINE: ROPE's agentdojo (@64495e16) is fetched at runtime; that its BaseAttack /
get_injection_candidates / task_suite / register_attack API matches this class, and that run_eval imports this module in
its subprocess, can only be confirmed by the live ROPE-clone smoke (see build_pisreplay_rope docstring)."""
import json
import os

from agentdojo.attacks.base_attacks import BaseAttack
from agentdojo.attacks.attack_registry import register_attack

_CACHE = None
_SRC = None


def _load_cache(arm=None):
    path = os.environ.get("UV2R_CACHE")
    if not path:
        raise RuntimeError("cache_injection needs UV2R_CACHE pointing at the released engine's injection cache")
    if arm:
        per = os.path.join(os.path.dirname(path), "injections_%s.json" % arm)
        if os.path.exists(per):
            path = per
    if not os.path.exists(path):
        raise RuntimeError("UV2R_CACHE file not found: %r" % path)
    raw = json.load(open(path))
    out = {}
    if isinstance(raw, dict):
        for suite, uts in raw.items():
            for ut, its in (uts or {}).items():
                for it, carrier in (its or {}).items():
                    out[(suite, ut, it)] = carrier
    else:
        for r in raw:
            out[(r["suite"], r["user_task"], r["injection_task"])] = r.get("carriers", r.get("carrier"))
    return out, path


def _cache():
    global _CACHE, _SRC
    if _CACHE is None:
        _CACHE, _SRC = _load_cache(os.environ.get("UV2R_ARM") or "rope")
    return _CACHE


def _stamp(rec):
    p = os.environ.get("UV2R_STAMP")
    if not p:
        return
    try:
        with open(p, "a") as fh:
            fh.write(json.dumps(rec) + "\n")
    except Exception:
        pass


@register_attack
class CacheInjectionAttack(BaseAttack):
    name = "cache_injection"

    def attack(self, user_task, injection_task):
        key = (self.task_suite.name, user_task.ID, injection_task.ID)
        carrier = _cache().get(key)
        if carrier is None:
            raise KeyError("cache_injection: no cached carrier for %s (cache %s)" % (key, _SRC))
        variants = carrier if isinstance(carrier, list) else [carrier]
        attempt = int(os.environ.get("UV2R_ATTEMPT", "0"))
        chosen = variants[attempt % len(variants)]
        _stamp({"event": "cache_attack", "suite": self.task_suite.name, "user_task": user_task.ID,
                "injection_task": injection_task.ID, "attempt": attempt, "n_variants": len(variants),
                "arm": os.environ.get("UV2R_ARM") or "rope", "cache_src": os.path.basename(_SRC or "")})
        return {inj: chosen for inj in self.get_injection_candidates(user_task)}
