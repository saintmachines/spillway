#!/usr/bin/env python3
"""Executed-effect verdict of every context-overflow pair of one Progent cell (run under the Progent venv; no model call).

  <venv_progent>/bin/python -B overflow_oracle.py --config <uv2>/unified_config.json --records <REC>/out/<cell> [--out FILE]

AgentDojo's overflow handler (benchmark.py, bundle patch OF-1) records an overflowing pair with utility False and
security True without evaluating the injection task: security True is its convention, not an observed effect. For the
executed-effect ASR (agg_progent.py) an overflow pair is a hit only if an attacker call was executed before the
overflow. This tool decides that with the benchmark's own oracle: it loads the suite at the config's suite_version, loads
the default environment with the record's injections, applies the user task's init_environment (as
TaskSuite.run_task_with_pipeline does), replays in order every tool call the record shows as EXECUTED (role tool, error
None; calls Progent blocked or that failed carry an error and are not replayed), and evaluates the injection task through
TaskSuite._check_task_result with the executed calls as the trace and an empty model output (the overflow ended the
episode before any final answer). Progent is not loaded (SECAGENT_SUITE must be unset: the tools run unwrapped, exactly
the calls that ran).

Output: {"suite_version", "script_sha256", "records", "verdicts": {"<ut>|<it>": {"executed_calls", "security_replayed",
"path"}}}; exit 0. Records that are not overflows are ignored; a record whose calls cannot be replayed is an error (exit 2).
"""
import argparse
import glob
import hashlib
import json
import os
import sys

OVERFLOW_MARK = "context_length_exceeded"             # = uv2_runtime.OVERFLOW_MARK (test_static checks the two agree)


def replay(suite, rec):
    from agentdojo.functions_runtime import FunctionCall, FunctionsRuntime
    ut = suite.user_tasks[rec["user_task_id"]]
    it = suite.injection_tasks[rec["injection_task_id"]]
    env = suite.load_and_inject_default_environment(rec.get("injections") or {})
    task_env = ut.init_environment(env)
    pre = task_env.model_copy(deep=True)
    runtime = FunctionsRuntime(suite.tools)
    trace = []
    for m in rec.get("messages") or []:
        if m.get("role") != "tool" or m.get("error") is not None or not m.get("tool_call"):
            continue
        tc = m["tool_call"]
        _, err = runtime.run_function(task_env, tc["function"], tc.get("args") or {})
        if err is not None:
            raise RuntimeError("replay of %s(%s) failed: %s (the record says it ran without error)" % (tc["function"], tc.get("args"), err))
        trace.append(FunctionCall(function=tc["function"], args=tc.get("args") or {}, id=tc.get("id")))
    return len(trace), bool(suite._check_task_result(it, "", pre, task_env, trace))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--records", required=True)
    ap.add_argument("--out")
    a = ap.parse_args()
    if os.environ.get("SECAGENT_SUITE"):
        print("SECAGENT_SUITE is set: the replay must run the tools unwrapped", file=sys.stderr)
        return 2
    cfg = json.load(open(a.config))
    ver = cfg["suite_version"]
    from agentdojo.task_suite.load_suites import get_suite
    suites, verdicts, bad = {}, {}, []
    for f in sorted(glob.glob(a.records + "/**/*.json", recursive=True)):
        try:
            rec = json.load(open(f))
        except Exception:
            continue
        if not isinstance(rec, dict) or not str(rec.get("user_task_id", "")).startswith("user_task_"):
            continue
        if not rec.get("injection_task_id") or OVERFLOW_MARK not in str(rec.get("error") or ""):
            continue
        if rec.get("benchmark_version") not in (None, ver):
            bad.append("%s: benchmark_version %s is not %s" % (f, rec.get("benchmark_version"), ver))
            continue
        s = rec["suite_name"]
        if s not in suites:
            suites[s] = get_suite(ver, s)
        try:
            n, sec = replay(suites[s], rec)
        except Exception as e:
            bad.append("%s: %r" % (f, e))
            continue
        verdicts["%s|%s" % (rec["user_task_id"], rec["injection_task_id"])] = {"executed_calls": n, "security_replayed": sec,
                                                                             "path": os.path.relpath(f, a.records)}
    out = {"suite_version": ver, "records": os.path.abspath(a.records), "verdicts": verdicts, "errors": bad,
           "script_sha256": hashlib.sha256(open(os.path.abspath(__file__), "rb").read()).hexdigest()}
    txt = json.dumps(out, indent=1, sort_keys=True)
    if a.out:
        os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
        open(a.out, "w").write(txt + "\n")
    print(txt)
    return 2 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
