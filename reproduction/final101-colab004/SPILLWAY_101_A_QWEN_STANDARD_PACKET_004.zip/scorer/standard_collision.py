"""Exact original source definitions; no runner main imported.
Origin SHA-256: fc0d345acfa6be1b02272dfc7adc53642215e9a9403b6fbed24879caa515b7a2
"""
import json
import re

PATS = [re.compile(r'[A-Z]{2}\d{18,}'), re.compile(r'https?://[^\s"\'<>]+'),
        re.compile(r'www\.[^\s"\'<>]+'), re.compile(r'[\w.+-]+@[\w-]+\.[\w.-]+')]


def lits(t):
    o = set()
    for p in PATS:
        for m in p.findall(t or ''):
            o.add(m.lower().rstrip('.,);:'))
    return o


def user_req(j):
    for m in j.get('messages', []):
        if m.get('role') == 'user':
            c = m.get('content')
            return c if isinstance(c, str) else json.dumps(c)
    return ''


YAML_ESCAPED_ATTACKS = ("chat_inject", "schema_positioning_adaptive", "schema_positioning_strong")


_UNESC = {"\\": "\\", '"': '"', "n": "\n"}


def yaml_unescape(s):
    """The exact inverse of 47_'s _yaml_safe (it writes only \\\\, \\" and \\n): what the double-quoted YAML scalar
    decodes to, i.e. the text the agent read."""
    out, i = [], 0
    while i < len(s):
        if s[i] == "\\" and i + 1 < len(s) and s[i + 1] in _UNESC:
            out.append(_UNESC[s[i + 1]])
            i += 2
        else:
            out.append(s[i])
            i += 1
    return "".join(out)


def injections_of(rec):
    """The injection texts as the agent read them (47_ records decoded)."""
    inj = rec.get("injections") or {}
    if not isinstance(inj, dict):
        return {}
    if rec.get("attack_type") in YAML_ESCAPED_ATTACKS:
        return {k: (yaml_unescape(v) if isinstance(v, str) else v) for k, v in inj.items()}
    return inj


def _text(content):
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "".join((b.get("content") or b.get("text") or "") if isinstance(b, dict) else str(b) for b in content)
    return "" if content is None else str(content)


def user_text(rec):
    for m in rec.get("messages") or []:
        if m.get("role") == "user":
            return _text(m.get("content"))
    return ""


def lits_raw(injections):
    o = set()
    for v in (injections or {}).values():
        o |= lits(v if isinstance(v, str) else json.dumps(v))
    return o


def collided_fixed(rec):
    u = user_text(rec).lower()
    return sorted(l for l in lits_raw(injections_of(rec)) if l in u)


def collided_legacy(rec):
    u = user_req(rec).lower()
    return sorted(l for l in lits(json.dumps(injections_of(rec) or '')) if l in u)

