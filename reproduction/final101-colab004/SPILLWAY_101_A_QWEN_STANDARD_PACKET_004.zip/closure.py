"""Exact UID closure using frozen paper executed/in-scope/overflow scorer."""
from __future__ import annotations
import collections
import importlib
import json
from pathlib import Path
import sys
from types import SimpleNamespace
from common import require, sha, planned, rows


def audit_calls(records, protocol, cell):
    records = Path(records)
    requests = rows(records / "calls.jsonl")
    require(bool(requests), "Actual agent request audit absent")
    decode = protocol["decode"]
    for row in requests:
        require(row.get("temperature") == decode["temperature"] and row.get("seed") == decode["seed"]
                and row.get("max_tokens") == decode["max_tokens"], "Request decode drift")
        require(row.get("system_sha256") == decode["system_prompt_sha256"][:16], "System prompt drift")
        if cell["model"].startswith("qwen3"):
            require(row.get("reasoning_effort") == "none", "Qwen hidden reasoning drift")
        require(not row.get("applied", {}).get("preflight_mismatch"), "Actual context preflight mismatch; paper-grade score withheld")
    provider = rows(records / "provider_responses.jsonl")
    from preprovider_accounting import reconcile
    request_accounting = reconcile(requests, provider, model=cell["model"],
        context=protocol["model_contexts"].get(cell["model"]), decode=decode,
        shim_path=Path(__file__).resolve().parent / "shim/conrac_agent_shim.py")
    require(all(r.get("provider_returned_model") and r.get("usage") for r in provider if not r.get("error_type")), "Provider identity/usage missing")
    judges = rows(records / "judge_requests.jsonl")
    for row in judges:
        require(row.get("model") == protocol["local_judge"] and row.get("http_status") == 200
                and not row.get("error_type") and row.get("provider_returned_model") == protocol["local_judge"], "Judge request/response failure")
        require(row["options"]["temperature"] == 0 and row["options"]["num_ctx"] == decode["judge_context"], "Judge decode drift")
    verdicts = rows(records / "judge_verdicts.jsonl")
    require(all(bool(row.get("voters")) and row.get("n_parsed") == len(row["voters"]) for row in verdicts),
            "JUDGE_PARSE_FAILURE: requested judge votes were not all parsed; score withheld")
    require(not judges or bool(verdicts), "Judge verdict audit absent")
    return {"agent_requests": len(requests), "provider_rows": len(provider), "judge_requests": len(judges),
            "agent_request_accounting": request_accounting,
            "agent_errors": sum(bool(r.get("error")) for r in requests),
            "provider_errors": sum(bool(r.get("error_type")) for r in provider),
            "context_render_mismatches": sum(bool(r.get("applied", {}).get("preflight_mismatch")) for r in requests),
            "cost_usd": sum(r.get("cost_usd") or 0 for r in provider),
            "provider_returned_models": sorted({r["provider_returned_model"] for r in provider if r.get("provider_returned_model")}),
            "logs_sha256": {p.name: sha(p) for p in (records / "calls.jsonl", records / "provider_responses.jsonl", records / "judge_requests.jsonl")}}


def select_records(records, cell):
    grouped = collections.defaultdict(list)
    for path in (Path(records) / "raw").rglob("*.json"):
        record = json.loads(path.read_text())
        if isinstance(record, dict) and "messages" in record and "user_task_id" in record:
            grouped[(record["user_task_id"], record.get("injection_task_id"))].append((record, path))
    wanted = {(row["user_task_id"], row["injection_task_id"]) for row in planned(cell)}
    require(set(grouped) == wanted and all(len(value) == 1 for value in grouped.values()),
            "Missing/foreign/duplicate UID: partial data remain unscored")
    selected = {key: value[0] for key, value in grouped.items()}
    for record, _ in selected.values():
        require(record.get("suite_name") == cell["suite"] and record.get("benchmark_version") == "v1.2.2", "Suite/version drift")
        require(record.get("attack_type") == (None if cell["attack"] == "none" else cell["attack"]), "Attack field drift")
        require(isinstance(record.get("utility"), bool) and isinstance(record.get("security"), bool), "Unscored/nonboolean record")
        error = record.get("error")
        require(error is None or any(t in str(error) for t in ("context_length_exceeded", "maximum context length is exceeded")),
                "Non-overflow runtime error: preserve partial and stop")
    return selected


def close(root, records, protocol, cell):
    root, records = Path(root), Path(records)
    selected = select_records(records, cell)  # no denominator shrinkage
    audit = audit_calls(records, protocol, cell)
    if cell["attack"] == "none":
        score = {"target_pairs": len(selected), "scored": len(selected), "missing": 0,
                 "utility": sum(r["utility"] is True for r, _ in selected.values()) / len(selected), "attack_ASR": "NOT_APPLICABLE"}
    else:
        sys.path.insert(0, str(root / "scorer"))
        extra = importlib.import_module("extra_rt")
        collision = importlib.import_module("standard_collision")
        rebut_goals = {suite: {task: set(values) for task, values in tasks.items()}
                       for suite, tasks in json.loads((root / "scorer/rebut_goals.json").read_text()).items()}
        goals = {"rebut": rebut_goals, "autodojo": extra.goals("autodojo", str(root / "attacks/autodojo_cache"))}
        from paper_scoring import score as score_paper
        score = score_paper(extra, collision, selected, cell, goals)
    require(score["scored"] == len(selected) and score["missing"] == 0, "Scorer closure failed")
    score["utility_hits"] = sum(r["utility"] is True for r, _ in selected.values())
    from attack_adapters import verify_output
    return {"status": "EXACT_UID_CELL_COMPLETE", "cell_id": cell["cell_id"], "worker_id": cell["worker_id"],
            "model": cell["model"], "profile": cell["profile"], "attack": cell["attack"], "suite": cell["suite"],
            "planned_uids": planned(cell), "score": score, "audit": audit,
            "attack_evidence": verify_output(records, cell),
            "records_sha256": {str(path.relative_to(records)): sha(path) for _, path in selected.values()},
            "scorer_sha256": {path.name: sha(path) for path in (root / "scorer").iterdir() if path.is_file()}}
