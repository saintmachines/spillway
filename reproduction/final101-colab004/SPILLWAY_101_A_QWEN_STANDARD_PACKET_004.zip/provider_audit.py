"""Observed provider/judge evidence with a process-safe local paid ledger.

The ledger must live on this runtime's local disk. Cross-VM paid execution is
forbidden by controller admission; Drive FUSE does not provide a global lock.
"""
from __future__ import annotations
from contextlib import contextmanager
import fcntl
import hashlib
import io
import json
import math
import os
from pathlib import Path
import shutil
import time
import urllib.parse
import urllib.request
import uuid
from common import positive, require


def append(path, row):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as output:
        output.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
        output.flush()
        os.fsync(output.fileno())


@contextmanager
def locked(path):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a+") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(lock, fcntl.LOCK_UN)


class BudgetLedger:
    def __init__(self, path, cap, mirror=None):
        require(positive(cap), "Positive finite hard cap required")
        self.path, self.cap = Path(path), float(cap)
        self.mirror = Path(mirror) if mirror is not None else None
        require("/drive/" not in str(self.path.resolve()), "Paid ledger must be local, not Drive FUSE")

    def latest(self):
        entries = [json.loads(line) for line in self.path.read_text().splitlines()] if self.path.exists() else []
        return {entry["request_id"]: entry for entry in entries}

    def reserve(self, request_id, amount):
        require(positive(amount), "Positive finite reservation required")
        with locked(str(self.path) + ".lock"):
            held = self.latest()
            require(request_id not in held, "Duplicate reservation ID")
            require(sum(entry["held_usd"] for entry in held.values()) + amount <= self.cap + 1e-12,
                    "Hard USD budget reservation would be exceeded")
            append(self.path, {"request_id": request_id, "state": "RESERVED", "held_usd": amount,
                               "cap_usd": self.cap, "no_auto_retry": True})
            if self.mirror is not None:
                self.mirror.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(self.path, self.mirror)

    def settle(self, request_id, actual):
        require(isinstance(actual, (int, float)) and not isinstance(actual, bool) and math.isfinite(actual) and actual >= 0,
                "Invalid actual cost")
        with locked(str(self.path) + ".lock"):
            old = self.latest().get(request_id)
            require(old is not None and old["state"] == "RESERVED", "No unsettled reservation")
            require(actual <= old["held_usd"] + 1e-12, "Observed usage exceeded reservation; preserve hold and stop")
            append(self.path, {"request_id": request_id, "state": "SETTLED", "held_usd": actual, "cap_usd": self.cap})
            if self.mirror is not None:
                self.mirror.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(self.path, self.mirror)


def require_paid_settings(settings):
    require(settings.get("paid_api_opt_in") is True, "Explicit paid opt-in required")
    require(positive(settings.get("hard_cap_usd")), "Positive finite hard cap required")
    prices = settings.get("prices") or {}
    require(bool(prices.get("verified_official_url")) and bool(prices.get("verified_utc")), "Official verified pricing required")
    require(urllib.parse.urlsplit(prices["verified_official_url"]).hostname in {"openai.com", "platform.openai.com", "developers.openai.com"},
            "Pricing must link to an official OpenAI source")
    for key in ("input", "cached_input", "output"):
        require(isinstance(prices.get(key), (float, int)) and not isinstance(prices[key], bool)
                and math.isfinite(prices[key]) and prices[key] >= 0, "Invalid price: " + key)
    require(prices.get("context_token_upper_bound", 0) >= 128000, "Reserve the full verified gpt-4o-mini input context")


def install_agent_audit(records, study_records, settings):
    from openai.resources.chat import completions
    original = completions.Completions.create
    paid = settings["backbone"].startswith("gpt-4o-mini")
    ledger = None
    if paid:
        require_paid_settings(settings)
        ledger = BudgetLedger(Path(study_records) / "PAID_RESERVATIONS.jsonl", settings["hard_cap_usd"],
                              mirror=Path(records).parent.parent / "PAID_RESERVATIONS.jsonl")

    def create(self, *args, **kwargs):
        # The typed SDK may leave omitted fields present as NOT_GIVEN/omit.
        # Remove these sentinels before fallback/accounting/JSON audit. Actual
        # provided values and the frozen shims' normalized values are kept.
        kwargs = {key: value for key, value in kwargs.items() if type(value).__name__ not in {"NotGiven", "Omit"}}
        request_id = uuid.uuid4().hex
        row = {"request_id": request_id, "utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
               "requested_model": kwargs.get("model"), "provider_returned_model": None, "usage": None,
               "settings": {key: kwargs.get(key) if isinstance(kwargs.get(key), (str, int, float, bool, type(None))) else None
                            for key in ("temperature", "seed", "max_tokens", "reasoning_effort")},
               "stream": kwargs.get("stream", False), "cost_usd": None, "paid": paid}
        reservation = None
        if paid:
            require_paid_settings(settings)
            base = urllib.parse.urlsplit(str(self._client.base_url))
            require(base.scheme == "https" and base.hostname == "api.openai.com", "Explicit official paid provider required")
            require(kwargs.get("stream", False) is False, "Streaming is outside this accounting contract")
            self._client.max_retries = 0
            prices = settings["prices"]
            output = kwargs.get("max_completion_tokens", kwargs.get("max_tokens"))
            require(isinstance(output, int) and output > 0, "Explicit bounded output tokens required")
            reservation = (prices["context_token_upper_bound"] * max(prices["input"], prices["cached_input"])
                           + output * prices["output"]) / 1e6
            ledger.reserve(request_id, reservation)
        started = time.monotonic()
        try:
            response = original(self, *args, **kwargs)
            returned_model, usage = getattr(response, "model", None), getattr(response, "usage", None)
            row["provider_returned_model"] = returned_model
            require(isinstance(returned_model, str) and bool(returned_model), "Provider returned model absent")
            require(usage is not None, "Provider usage absent")
            if paid:
                require(returned_model == settings["backbone"], "Provider model substitution: exact frozen snapshot required")
            identity = {"requested_model": kwargs.get("model"), "provider_returned_model": returned_model}
            identity_path = Path(study_records) / ("MODEL_IDENTITY_" + hashlib.sha256(str(kwargs.get("model")).encode()).hexdigest()[:12] + ".json")
            with locked(str(identity_path) + ".lock"):
                if identity_path.exists():
                    require(json.loads(identity_path.read_text()) == identity, "Returned model changed within study")
                else:
                    identity_path.write_text(json.dumps(identity, indent=2) + "\n")
            usage = usage.model_dump() if hasattr(usage, "model_dump") else {
                name: getattr(usage, name, None) for name in ("prompt_tokens", "completion_tokens", "total_tokens")}
            row.update(provider_returned_model=returned_model, usage=usage)
            if not paid and settings.get("local_endpoint"):
                row["model_residency"] = observe_residency(settings["local_endpoint"], settings["backbone"],
                    settings.get("agent_context"), settings.get("require_cuda_residency", False))
            if paid:
                require(all(isinstance(usage.get(k), int) and usage[k] >= 0 for k in ("prompt_tokens", "completion_tokens")), "Invalid usage")
                cached = (usage.get("prompt_tokens_details") or {}).get("cached_tokens", 0) or 0
                require(isinstance(cached, int) and 0 <= cached <= usage["prompt_tokens"], "Invalid cached token count")
                actual = ((usage["prompt_tokens"] - cached) * prices["input"] + cached * prices["cached_input"]
                          + usage["completion_tokens"] * prices["output"]) / 1e6
                require(actual <= reservation + 1e-12, "Usage exceeded reservation")
                ledger.settle(request_id, actual)
                row["cost_usd"] = actual
            else:
                row.update(cost_usd=0.0, cost_scope="API dollars only; Colab CU/GPU compute not priced")
            return response
        except Exception as error:
            # No exception text, request text, headers or credential values are logged.
            row["error_type"] = type(error).__name__
            raise
        finally:
            row["latency_s"] = round(time.monotonic() - started, 4)
            append(Path(records) / "provider_responses.jsonl", row)
    completions.Completions.create = create


class ObservedResponse(io.BytesIO):
    def __init__(self, raw, original):
        super().__init__(raw)
        self.status, self.headers, self.url = original.status, original.headers, original.url

    def getcode(self):
        return self.status


def observe_residency(endpoint, model, context, require_cuda=False):
    with urllib.request.urlopen(endpoint + "/api/ps", timeout=10) as response:
        found = [row for row in json.load(response).get("models", []) if row.get("name", row.get("model")) == model]
    require(len(found) == 1, "Requested model not uniquely resident")
    row = found[0]
    result = {key: row.get(key) for key in ("name", "model", "digest", "size", "size_vram", "context_length")}
    if context is not None:
        require(row.get("context_length") == context, "Resident model context differs from frozen request")
    if require_cuda:
        require(isinstance(row.get("size"), int) and row["size"] > 0 and row.get("size_vram") == row["size"],
                "Partial GPU residency/offload detected; stop without a fallback")
    return result


def install_judge_audit(records, endpoint, require_cuda=False, judge_context=4096):
    original = urllib.request.urlopen
    path = Path(records) / "judge_requests.jsonl"
    path.touch(exist_ok=False)

    def urlopen(request, *args, **kwargs):
        url = getattr(request, "full_url", str(request))
        if url != endpoint + "/api/generate":
            return original(request, *args, **kwargs)
        sent = json.loads(request.data)
        row = {"model": sent.get("model"), "options": sent.get("options"), "think": sent.get("think"), "format": sent.get("format"),
               "prompt_sha256": hashlib.sha256(sent.get("prompt", "").encode()).hexdigest()}
        started = time.monotonic()
        try:
            response = original(request, *args, **kwargs)
            raw = response.read()
            parsed = json.loads(raw)
            row.update(http_status=response.status, provider_returned_model=parsed.get("model"),
                       usage={name: parsed.get(name) for name in ("prompt_eval_count", "eval_count", "total_duration")},
                       response_sha256=hashlib.sha256(raw).hexdigest(), done_reason=parsed.get("done_reason"))
            require(bool(row["provider_returned_model"]), "Judge returned model absent")
            row["model_residency"] = observe_residency(endpoint, row["provider_returned_model"], judge_context, require_cuda)
            wrapped = ObservedResponse(raw, response)
            response.close()
            return wrapped
        except Exception as error:
            row["error_type"] = type(error).__name__
            raise
        finally:
            row["latency_s"] = round(time.monotonic() - started, 4)
            append(path, row)
    urllib.request.urlopen = urlopen
