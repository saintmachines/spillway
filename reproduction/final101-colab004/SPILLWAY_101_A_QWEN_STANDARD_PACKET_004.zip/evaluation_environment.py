"""Seed the exact frozen evaluation venv under current paper-family Python3.13."""
from __future__ import annotations
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

PAPER_PYTHON = [3, 13, 15]


def require_pinned_uv_version(output):
    if output.strip().split()[:2] != ["uv", "0.11.6"]:
        raise RuntimeError("Pinned uv0.11.6 required")


def probe(python):
    result = subprocess.run([str(python), "-I", "-c", "import json,sys,pip;print(json.dumps({'version':list(sys.version_info[:3]),'executable':sys.executable,'base_executable':sys._base_executable,'prefix':sys.prefix,'pip_file':pip.__file__}))"],
                            capture_output=True, text=True, timeout=20)
    if result.returncode:
        return None
    info = json.loads(result.stdout)
    pip = subprocess.run([str(python), "-I", "-m", "pip", "--version"], capture_output=True, text=True, timeout=20)
    if pip.returncode:
        return None
    info["pip_version_output"] = pip.stdout.strip()
    return info


def get_uv(owned, env):
    candidates = [shutil.which("uv"), str(owned / "uv_0_11_6/bin/uv"), str(owned / "uv_0_11_6/uv/uv")]
    for candidate in candidates:
        if candidate and Path(candidate).is_file():
            result = subprocess.run([candidate, "--version"], env=env, capture_output=True, text=True)
            if result.returncode == 0:
                try:
                    require_pinned_uv_version(result.stdout)
                    return candidate, result.stdout.strip()
                except RuntimeError:
                    pass
    target = owned / "uv_0_11_6"
    subprocess.run([sys.executable, "-m", "pip", "install", "--disable-pip-version-check", "--no-deps", "--target", str(target), "uv==0.11.6"], env=env, check=True)
    env["PYTHONPATH"] = str(target)
    for candidate in [target / "bin/uv", target / "uv/uv"]:
        if candidate.is_file():
            version = subprocess.check_output([str(candidate), "--version"], env=env, text=True)
            require_pinned_uv_version(version)
            return str(candidate), version.strip()
    raise RuntimeError("Pinned uv binary unavailable; no interpreter replacement")


def prepare(root, content_root=Path("/content")):
    if sys.version_info[:2] != (3, 13):
        raise RuntimeError("Paper receipts use Python3.13.15; this evaluation requires current Python3.13. No3.12 fallback.")
    protocol = json.loads((Path(root) / "PROTOCOL.json").read_text())
    state = Path(content_root) / ("spw_final014_" + protocol["artifact"]["wheel_sha256"][:12])
    target = state / "venv"
    cfg = target / "pyvenv.cfg"
    python = target / "bin/python"
    reused = target.exists()
    if not reused:
        owned = Path(content_root) / "spillway_two_uv_seed"
        owned.mkdir(parents=True, exist_ok=True)
        env = dict(os.environ)
        env.pop("OPENAI_API_KEY", None)
        env.pop("UV_VENV_CLEAR", None)
        uv, uv_version = get_uv(owned, env)
        subprocess.run([uv, "--cache-dir", str(owned / "cache"), "--no-config", "venv", "--seed", "--no-project", "--no-python-downloads",
                        "--python", sys.executable, "--default-index", "https://pypi.org/simple", str(target)], env=env, check=True)
    else:
        uv_version = "not invoked: existing target validated"
    info = probe(python) if python.is_file() and cfg.is_file() else None
    if not info or info["version"] != list(sys.version_info[:3]) or Path(info["prefix"]).resolve() != target.resolve() or not Path(info["pip_file"]).resolve().is_relative_to(target.resolve()):
        raise RuntimeError("Existing/created evaluation venv is partial, wrongPython or lackspip. Preserved at " + str(target) + "; inspect before a clean new admission; no automatic clearing.")
    config = dict(line.split(" = ", 1) for line in cfg.read_text().splitlines() if " = " in line)
    declared = config.get("version_info", config.get("version", ""))
    if not declared.startswith(".".join(map(str, info["version"]))) or config.get("include-system-site-packages", "").lower() != "false":
        raise RuntimeError("Evaluation pyvenv.cfg differs; target preserved without overwrite")
    result = {"status": "EXACT_FROZEN_STATE_PIP_SEEDED_PY313", "target": str(target), "current_python": list(sys.version_info[:3]),
              "paper_python": PAPER_PYTHON, "paper_patch_match": list(sys.version_info[:3]) == PAPER_PYTHON,
              "uv_version": uv_version, "reused_complete_target": reused, "evaluation_probe": info,
              "stdlib_ensurepip_not_invoked": True, "older_python312_bootstrap_preserved": True}
    state.mkdir(parents=True, exist_ok=True)
    (state / "EVALUATION_VENV_RECEIPT.json").write_text(json.dumps(result, indent=2) + "\n")
    return result
