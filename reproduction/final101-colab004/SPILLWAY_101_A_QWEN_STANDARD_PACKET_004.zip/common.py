"""Metadata-only primitives. Importing this module cannot start a model."""
from __future__ import annotations
import hashlib
import json
import math
from pathlib import Path


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(8 * 1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def dump(path, value, exclusive=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x" if exclusive else "w") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def read(path):
    return json.loads(Path(path).read_text())


def rows(path):
    path = Path(path)
    return [json.loads(line) for line in path.read_text().splitlines() if line] if path.exists() else []


def positive(value):
    return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value) and value > 0


def manifest_digest(files):
    """Canonical source manifest: sha256 of sorted '<sha256>  <path>\\n'."""
    return hashlib.sha256("".join(f"{digest}  {name}\n" for name, digest in sorted(files.items())).encode()).hexdigest()


def uid(cell, user, injection):
    return "|".join([cell["cell_id"], cell["suite"], user, injection or "BENIGN"])


def planned(cell):
    users = cell["user_task_ids"]
    injections = [None] if cell["attack"] == "none" else cell["injection_task_ids"]
    return [{"uid": uid(cell, user, injection), "suite": cell["suite"], "user_task_id": user,
             "injection_task_id": injection} for user in users for injection in injections]


def worker_for(suite, user, workers):
    # All profiles/attacks of the same base mission stay on the same worker.
    return int(hashlib.sha256((suite + "|" + user).encode()).hexdigest(), 16) % workers


def split_cells(cells, workers, paid=False):
    require(isinstance(workers, int) and 1 <= workers <= 16, "worker count must be 1..16")
    if paid:
        require(workers == 1, "Paid API dispatch is restricted to one runtime; Drive locks are not a global budget service")
    result = {str(i): [] for i in range(workers)}
    all_uids = set()
    for source in cells:
        require(source.get("artifact", "final014") == "final014", "Only final014 execution is allowed")
        whole = planned(source)
        require(len({row["uid"] for row in whole}) == len(whole), "Duplicate UID within source cell")
        require(not (all_uids & {row["uid"] for row in whole}), "Duplicate source cell UID")
        all_uids.update(row["uid"] for row in whole)
        for worker in range(workers):
            users = [u for u in source["user_task_ids"] if worker_for(source["suite"], u, workers) == worker]
            if users:
                cell = {**source, "user_task_ids": users, "worker_id": str(worker)}
                cell["planned_uids"] = planned(cell)
                result[str(worker)].append(cell)
    actual = [row["uid"] for group in result.values() for cell in group for row in cell["planned_uids"]]
    require(len(actual) == len(set(actual)) == len(all_uids) and set(actual) == all_uids, "Shard UID coverage failed")
    return result
