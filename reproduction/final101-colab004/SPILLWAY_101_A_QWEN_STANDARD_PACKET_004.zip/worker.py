"""One final014 suite/profile shard through the installed actual caller."""
from __future__ import annotations
import argparse
import importlib
import importlib.metadata
import json
import os
from pathlib import Path
import sys
import urllib.request
from common import dump, planned, read, require, sha
from runtime import require_live_ready


def verify_installed(root, protocol):
    artifact = protocol["artifact"]
    distribution = importlib.metadata.distribution("spillway-guard")
    require(distribution.version == "1.0.1", "Installed version must be exactly final014")
    for name, digest in artifact["source_files"].items():
        require(sha(distribution.locate_file(name)) == digest, "Installed final source drift: " + name)
    dep = importlib.metadata.distribution("agentdojo")
    require(dep.version == protocol["agentdojo"]["version"], "AgentDojo version mismatch")
    for name, digest in protocol["agentdojo"]["installed_files"].items():
        require(sha(dep.locate_file(name)) == digest, "AgentDojo source/data drift: " + name)
    import spillway_guard
    import agentdojo
    require(Path(spillway_guard.__file__).resolve() == Path(distribution.locate_file("spillway_guard/__init__.py")).resolve(),
            "Imported SDK shadows the verified distribution")
    require(Path(agentdojo.__file__).resolve() == Path(dep.locate_file("agentdojo/__init__.py")).resolve(),
            "Imported AgentDojo shadows the verified distribution")
    reference = Path(root) / "reference"
    for name, digest in artifact["reference_files"].items():
        require(sha(reference / name) == digest, "Reference source drift: " + name)
    from agentdojo.task_suite import get_suites
    suites = get_suites(protocol["agentdojo"]["suite_version"])
    for name, grid in protocol["grid"].items():
        require(set(suites[name].user_tasks) == set(grid["user_task_ids"]), "Suite user task set differs")
        require(set(suites[name].injection_tasks) == set(grid["injection_task_ids"]), "Suite injection task set differs")
    return {"distribution_version": distribution.version, "source_files_verified": len(artifact["source_files"]),
            "reference_files_verified": len(artifact["reference_files"]), "agentdojo_files_verified": len(protocol["agentdojo"]["installed_files"])}


def configure_environment(root, records, protocol, cell, endpoint):
    # Clear historical environment switches before constructing this cell.
    for key in list(os.environ):
        if key.startswith(("SPW_", "CONRAC_", "UV2X_", "UV2R_")) or key in {"SECAGENT_SUITE", "OPENAI_BASE_URL"}:
            os.environ.pop(key)
    local = not cell["model"].startswith("gpt-")
    rules = {"qwen3": {"reasoning_effort": "none"}} if local else {"openai": {}}
    decode = protocol["decode"]
    env = {"SPW_REFERENCE_DIR": str(Path(root) / "reference"), "SPW_OLLAMA_URL": endpoint, "CONRAC_OLLAMA_URL": endpoint,
           "SPW_OUT_DIR": str(Path(records) / "derived"), "CONRAC_OUT_DIR": str(Path(records) / "derived"),
           "SPW_VOTERS": protocol["local_judge"], "SPW_JUDGE_LOG": str(Path(records) / "judge_verdicts.jsonl"),
           "SPW_PAYLOAD_SECRET_GUARD": "0", "SPW_PAYLOAD_PARTIAL_GUARD": "0", "SPW_DELEGATION_SPAN_VETO": "0",
           "CONRAC_SHIM": "1", "CONRAC_SHIM_RULES": json.dumps(rules),
           "CONRAC_DEFAULT_PROMPT_FILE": str(Path(root) / "shim/agentdojo_default_prompt.txt"), "CONRAC_FORCE_DEFAULT_PROMPT": "1",
           "CONRAC_PROMPT_SUFFIXES": "{}", "CONRAC_MAX_TOKENS": str(decode["max_tokens"]),
           "CONRAC_TEMPERATURE": str(decode["temperature"]), "CONRAC_SEED": str(decode["seed"]),
           "CONRAC_SUITE_VERSION": protocol["agentdojo"]["suite_version"], "CONRAC_INJ_MODEL_NAME": "Local model" if local else "GPT-4",
           "CONRAC_REQUEST_TIMEOUT": "600", "CONRAC_CALL_LOG": str(Path(records) / "calls.jsonl"),
           "CONRAC_CALL_TAG": "|".join(("final101", cell["profile"], cell["attack"], cell["cell_id"], cell["worker_id"]))}
    if local:
        context = protocol["model_contexts"].get(cell["model"])
        require(isinstance(context, int) and context > 0, "Missing pinned backbone context window")
        env.update(CONRAC_CONTEXT_WINDOW=str(context), CONRAC_OLLAMA_PREFLIGHT=endpoint)
    os.environ.update(env)
    sys.path.insert(0, str(Path(root) / "shim"))


def main():
    parser = argparse.ArgumentParser()
    for name in ("root", "records", "study-records", "settings", "cell"):
        parser.add_argument("--" + name, type=Path, required=True)
    parser.add_argument("--endpoint", required=True)
    args = parser.parse_args()
    root, records = args.root.resolve(), args.records.resolve()
    settings, cell = read(args.settings), read(args.cell)
    protocol = require_live_ready(root, settings)
    expected = protocol["dispatches"][settings["dispatch"]]["workers"][str(settings["worker_id"]) ]
    require(cell in expected, "Cell differs from immutable assigned shard")
    require(cell["profile"] in protocol["profiles"], "Unknown frozen profile")
    metadata = verify_installed(root, protocol)
    with urllib.request.urlopen(args.endpoint + "/api/tags", timeout=10) as response:
        models = {row["name"]: row["digest"] for row in json.load(response)["models"]}
    needed = {protocol["local_judge"]} | ({cell["model"]} if not cell["model"].startswith("gpt-") else set())
    for name in needed:
        require(name in protocol["models"] and models.get(name) == protocol["models"][name], "Served model digest drift: " + name)
    configure_environment(root, records, protocol, cell, args.endpoint)
    # Audit the normalized transport request: install the observer first, then
    # let the frozen paper shim and installed runner shim wrap it. Installing
    # the observer last would see SDK NOT_GIVEN values before normalization.
    from provider_audit import install_agent_audit, install_judge_audit
    per_cell_settings = {**settings, "backbone": cell["model"], "local_endpoint": args.endpoint,
                         "agent_context": protocol["model_contexts"].get(cell["model"]),
                         "require_cuda_residency": settings["execution_location"] == "Colab"}
    install_agent_audit(records, args.study_records, per_cell_settings)
    install_judge_audit(records, args.endpoint, require_cuda=settings["execution_location"] == "Colab",
                        judge_context=protocol["decode"]["judge_context"])
    import conrac_agent_shim  # Frozen paper renderer/context-bound audit.
    from attack_adapters import install as install_attack
    attack_metadata = install_attack(root, records, cell)
    from spillway_guard.agentdojo import runner
    flags = ["--suite", cell["suite"], "--agent-model", cell["model"], "--attack", cell["attack"],
             "--user-tasks", ",".join(cell["user_task_ids"]), "--logdir", str(records / "raw"),
             "--run-id", "final101_" + cell["cell_id"], "--summary-tag", "final101_" + cell["cell_id"],
             *protocol["profiles"][cell["profile"]]["flags"]]
    if cell["attack"] != "none":
        flags += ["--injection-tasks", ",".join(cell["injection_task_ids"])]
    forwarded, reference = runner.prepare(flags)
    require(Path(reference).resolve() == (root / "reference").resolve(), "Actual reference directory differs")
    gate = importlib.import_module(os.environ.get("SPW_REFERENCE_MODULE", "spillway_gate"))
    runner.patch_gate(gate)
    wrapped = getattr(gate.gate_decision_v13b, "_spw_candidate_policy", None)
    require(wrapped is not None, "Actual decision caller lacks final014 policy")
    expected_policy = protocol["expected_policy"]
    actual_policy = {name: getattr(wrapped, name) for name in expected_policy}
    require(actual_policy == expected_policy, "Actual final policy differs from frozen profile")
    cfg = getattr(gate.SchemaProvenanceToolsExecutor, "_spw_raw_capture_config", {})
    require(cfg.get("source") and cfg.get("resource") and not cfg.get("sensitive"), "Actual executor capture differs")
    capture = {"no_redirect_tools": sorted(cfg["contracts"].no_redirect_tools),
               "fresh_creation_tools": sorted(cfg["creation_contracts"].fresh_tools)}
    require(capture == protocol["host_contracts"], "Automatic benchmark host contracts differ")
    expected_recovery = protocol["profiles"][cell["profile"]]["identity_recovery"]
    effective = {key: value for key, value in os.environ.items() if key.startswith(("SPW_", "CONRAC_"))
                 and any(key.endswith("_" + suffix) for suffix in ("ESCALATE_MV", "MV_INTEGRITY", "MV_GUARD", "ROLEMARK", "REFBIND",
                     "GROUND_TARGETS", "TYPED_IDENTITY_ONLY", "SHORT_TARGET_GUARD", "STRICT_FETCH_PROVENANCE", "PAYLOAD_SECRET_GUARD", "PAYLOAD_PARTIAL_GUARD"))}
    require({v for k, v in effective.items() if k.endswith("_ESCALATE_MV")} == {"1" if expected_recovery else "0"}, "Recovery profile differs in actual caller")
    dump(records / "PLANNED_UIDS.json", planned(cell), exclusive=True)
    metadata.update(cell=cell, protocol_sha256=sha(root / "PROTOCOL.json"), wheel_sha256=protocol["artifact"]["wheel_sha256"],
                    prepared_flags=forwarded, actual_environment=effective, actual_candidate_policy=actual_policy,
                    actual_executor_contracts=capture, frozen_decode=protocol["decode"], model_digests={n: models[n] for n in needed},
                    attack_adapter=attack_metadata, semantic_gate_sha256=sha(root / "SEMANTIC_GATE.json"))
    dump(records / "CELL_PREFLIGHT.json", metadata, exclusive=True)
    sys.argv = ["spillway-agentdojo", *forwarded]
    code = int(gate.main() or 0)
    require(code == 0, "Reference runtime failed")
    from closure import close
    closure = close(root, records, protocol, cell)
    closure.update(artifact=protocol["artifact"], preflight_sha256=sha(records / "CELL_PREFLIGHT.json"))
    dump(records / "CELL_CLOSURE.json", closure, exclusive=True)
    print(json.dumps({"status": closure["status"], "cell_id": cell["cell_id"], "rows": len(planned(cell))}))


if __name__ == "__main__":
    main()
