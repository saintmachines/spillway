"""Existing measured scorer guard plus auxiliary reader, then original worker."""
from pathlib import Path
import importlib.util
import sys
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT))
spec=importlib.util.spec_from_file_location('spillway_final014_scorer_guard',ROOT/'scorer_guard.py')
guard=importlib.util.module_from_spec(spec);spec.loader.exec_module(guard)
from native_auxiliary import install
install()
from worker import main
if __name__=='__main__':main()
