"""Reconcile the frozen serial shim with actual provider attempts.

A context preflight rejection is an agent request but is not an HTTP completion.
It remains a scored failure under the original scorer. Never create a fake
provider response, change the context, retry, or remove its benchmark UID.
"""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re

from common import require

FROZEN_SHIM_SHA256 = 'c220d355a41f88902c42908459b3bf69999c120e7f8357ddca44f4982990a443'
PREFLIGHT = re.compile(
    r'''BadRequestError\(["']This model's maximum context length is exceeded: prompt '''
    r'''(\d+) \+ max_tokens (\d+) > context window (\d+)\. '''
    r'''Please reduce the length of the messages\.["']\)'''
)


def canonical_sha(value):
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False)
    return hashlib.sha256(raw.encode()).hexdigest()


def reconcile(requests, provider, *, model, context, decode, shim_path):
    """Strict ordinal join for the original single-thread, nonstreaming lane."""
    require(hashlib.sha256(Path(shim_path).read_bytes()).hexdigest() == FROZEN_SHIM_SHA256,
            'Context preflight accounting requires the exact frozen shim')
    ids = [r.get('request_id') for r in provider]
    require(all(isinstance(x, str) and x for x in ids) and len(ids) == len(set(ids)),
            'Missing or duplicate provider request ID')
    consumed, preflight, joined = 0, [], []
    for index, request in enumerate(requests):
        require(request.get('model') == model, 'Agent request model changed')
        for key in ('temperature', 'seed', 'max_tokens'):
            require(request.get(key) == decode[key], 'Agent request decode differs: ' + key)
        error = request.get('error')
        match = PREFLIGHT.fullmatch(error) if isinstance(error, str) else None
        # Only the exact shim branch before orig(self, ...) has no successful
        # preflight token count and no response usage. An HTTP error cannot be
        # silently counted here: it leaves a provider row and breaks the join.
        before_provider = (match is not None and request.get('prompt_tokens') is None
                           and 'preflight_prompt_tokens' not in request.get('applied', {}))
        if before_provider:
            prompt, output, window = map(int, match.groups())
            require(model.startswith('qwen3') and request.get('family') == 'qwen3'
                    and request.get('shim') == 'v2' and request.get('reasoning_effort') == 'none',
                    'Unexpected context preflight source')
            require(type(context) is int and window == context and output == decode['max_tokens']
                    and output == request.get('max_tokens') and prompt > 0 and prompt + output > window,
                    'Context preflight arithmetic differs from the frozen request')
            preflight.append({'request_ordinal': index, 'request_record_sha256': canonical_sha(request),
                              'source': 'derived_from_original_shim_record_not_a_provider_response',
                              'reason': 'context_length_exceeded_before_provider',
                              'prompt_tokens': prompt, 'max_tokens': output, 'context_window': window,
                              'actual_completion_HTTP_attempts': 0, 'benchmark_UID_removed': False})
            continue
        require(consumed < len(provider), 'Missing provider response for an actual provider attempt')
        response = provider[consumed]
        require(response.get('requested_model') == model and response.get('stream', False) is False,
                'Provider request model or stream differs')
        settings = response.get('settings', {})
        for key in ('temperature', 'seed', 'max_tokens'):
            require(settings.get(key) == request.get(key) == decode[key], 'Provider decode join differs: ' + key)
        if response.get('error_type'):
            require(isinstance(error, str) and error.startswith(response['error_type'] + '('),
                    'Provider error has no matching original shim exception')
        else:
            require(response.get('provider_returned_model') == model and response.get('usage'),
                    'Successful provider response lacks identity or usage')
            for field in ('prompt_tokens', 'completion_tokens'):
                require(request.get(field) == response['usage'].get(field), 'Provider usage join differs: ' + field)
        joined.append({'request_ordinal': index, 'provider_ordinal': consumed,
                       'provider_request_id': response['request_id'],
                       'request_record_sha256': canonical_sha(request),
                       'provider_record_sha256': canonical_sha(response)})
        consumed += 1
    require(consumed == len(provider), 'Unmatched or excess provider response')
    require(len(joined) + len(preflight) == len(requests), 'Agent request accounting incomplete')
    return {'status': 'ALL_AGENT_REQUESTS_ACCOUNTED_FOR_WITHOUT_SYNTHETIC_PROVIDER_ROWS',
            'actual_provider_attempts': consumed, 'preprovider_context_rejections': len(preflight),
            'derived_preprovider_rejections': preflight, 'request_provider_join': joined,
            'scoring_or_decode_changed': False, 'overflow_failures_retained': True}
