"""Child runs the pinned original worker; never reads paid credentials."""
import json
import os
from pathlib import Path
import sys


def main():
    spec = json.loads(Path(sys.argv[1]).read_text())
    root = Path(spec['root']).resolve()
    sys.path.insert(0, str(root))
    os.environ.pop('OPENAI_API_KEY', None)
    import runtime
    result = runtime.run_worker(root, spec['drive_root'], spec['installed'], spec['server'], spec['settings'])
    print(json.dumps(result, ensure_ascii=False))


if __name__ == '__main__':
    main()
