"""Close the exact requested inventory; partial/foreign/duplicate data are unscored."""
from __future__ import annotations
import argparse
import collections
import json
from pathlib import Path
from common import dump, planned, read, require, sha
from runtime import inspect_packet


def aggregate(root, run_root):
    root, run_root = Path(root).resolve(), Path(run_root).resolve()
    inspect_packet(root)
    protocol = read(root / "PROTOCOL.json")
    expected = {}
    for dispatch, desc in protocol["dispatches"].items():
        for worker, cells in desc["workers"].items():
            for cell in cells:
                expected[(dispatch, worker, cell["cell_id"])] = cell
    observed = {}
    failures = []
    for path in run_root.glob("*/*/cells/*/CELL_CLOSURE.json"):
        try:
            dispatch, worker, _, cell_id, _ = path.relative_to(run_root).parts
            key = dispatch, worker, cell_id
            require(key in expected and key not in observed, "Foreign/duplicate cell closure")
            closure = read(path)
            cell = expected[key]
            require(closure["status"] == "EXACT_UID_CELL_COMPLETE", "Cell is incomplete")
            require(closure["artifact"] == protocol["artifact"], "Artifact drift in result")
            require(closure["planned_uids"] == planned(cell), "UID assignment differs in result")
            require(closure["score"]["scored"] == len(planned(cell)) and closure["score"]["missing"] == 0, "Missing scored UID")
            require(sha(path.parent / "CELL_PREFLIGHT.json") == closure["preflight_sha256"], "Preflight drift")
            for name, digest in closure["records_sha256"].items():
                require(sha(path.parent / name) == digest, "Raw record drift")
            for name, digest in closure["audit"]["logs_sha256"].items():
                require(sha(path.parent / name) == digest, "Request audit drift")
            for name, digest in closure["scorer_sha256"].items():
                require(sha(root / "scorer" / name) == digest, "Scorer differs from result")
            run_key = read(run_root / dispatch / worker / "RUN_KEY.json")
            require(run_key["protocol_sha256"] == sha(root / "PROTOCOL.json")
                    and run_key["inventory_protocol_sha256"] == protocol["inventory_protocol_sha256"], "Run protocol drift")
            closure["observed_execution_location"] = run_key["platform"]
            observed[key] = closure
        except Exception as error:
            failures.append({"path": str(path), "failure_type": type(error).__name__})
    missing = sorted(set(expected) - set(observed))
    result = {"status": "PARTIAL_UNSCORED", "scope": protocol["scope"], "expected_cell_shards": len(expected),
              "complete_cell_shards": len(observed), "expected_records": sum(len(planned(c)) for c in protocol["cells"]),
              "closed_records": sum(len(c["planned_uids"]) for c in observed.values()),
              "missing_shards": [list(key) for key in missing], "failures": failures,
              "publication_or_historical_metric_replacement": False}
    complete_ids = {cell["cell_id"] for cell in protocol["cells"]
                    if all(key in observed for key in expected if key[2] == cell["cell_id"])}
    result["complete_original_cells"] = sorted(complete_ids)
    standard_ids = {c["cell_id"] for c in protocol["cells"] if c["group"].startswith("standard_")}
    result["standard_matrix_complete"] = standard_ids <= complete_ids and not failures
    if not complete_ids:
        return result
    grouped = collections.defaultdict(list)
    all_uids = []
    for key, closure in observed.items():
        cell = expected[key]
        if cell["cell_id"] not in complete_ids:
            continue
        grouped[(cell["group"], cell["model"], cell["profile"], cell["suite"], closure["observed_execution_location"])].append(closure)
        all_uids.extend(row["uid"] for row in closure["planned_uids"])
    require(len(all_uids) == len(set(all_uids)), "Duplicate closed UID")
    if not missing and not failures:
        require(len(all_uids) == result["expected_records"], "Global UID coverage mismatch")
    summaries = []
    for (group, model, profile, suite, location), closures in sorted(grouped.items()):
        denominator = sum(c["score"]["scored"] for c in closures)
        utility_hits = sum(c["score"]["utility_hits"] for c in closures)
        row = {"group": group, "model": model, "profile": profile, "suite": suite, "denominator": denominator,
               "utility_hits": utility_hits, "utility": utility_hits / denominator,
               "platform": location,
               "overflow": sum(c["score"].get("overflow", 0) for c in closures),
               "cost_usd": sum(c["audit"]["cost_usd"] for c in closures)}
        if "hits" in closures[0]["score"]:
            hits = {name: sum(c["score"]["hits"][name] for c in closures)
                    for name in ("raw", "executed", "collision", "content_manip", "in_scope")}
            scope_denominator = sum(c["score"]["in_scope_denominator"] for c in closures)
            reported_denominator = sum(c["score"]["original_reported_asr_denominator"] for c in closures)
            reported_numerator = sum(c["score"]["original_reported_asr_numerator"] for c in closures)
            row.update(hits=hits, raw_asr=hits["raw"] / denominator, executed_asr=hits["executed"] / denominator,
                       in_scope_denominator=scope_denominator, in_scope_asr=hits["in_scope"] / scope_denominator if scope_denominator else None,
                       original_reported_asr_numerator=reported_numerator,
                       original_reported_asr_denominator=reported_denominator,
                       original_reported_asr=reported_numerator / reported_denominator if reported_denominator else None,
                       original_reporting_rule=closures[0]["score"]["original_reporting_rule"])
        summaries.append(row)
    status = ("EXACT_REQUESTED_UID_SCOPE_COMPLETE_REQUIRES_PAPER_ANALYSIS" if not missing and not failures
              else "PARTIAL_SCOPE_COMPLETE_CELLS_AVAILABLE")
    result.update(status=status, suites=summaries,
                  paired_CI="NOT_COMPUTED", historical_comparison="NOT_COMPUTED", broader_paper_tables_complete=False)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", required=True, type=Path)
    parser.add_argument("--run-root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    result = aggregate(args.root, args.run_root)
    dump(args.output, result)
    print(json.dumps({k: result[k] for k in ("status", "expected_records", "closed_records", "complete_cell_shards", "expected_cell_shards")}, indent=2))


if __name__ == "__main__":
    main()
