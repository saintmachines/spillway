"""Register original paper attacks in the installed final014 actual caller.

Adapters are imported only by an explicit worker/probe, never by inspection.
Original attack files and all caches are packet-hashed. No attacker generation
API is called here; AutoDojo/PISmith are the paper's frozen open-loop payloads.
"""
from __future__ import annotations
import importlib.util
import json
import os
from pathlib import Path
from common import require, rows, sha


def load_file(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def install(root, records, cell):
    root, records = Path(root), Path(records)
    original = root / "attacks/original"
    attack = cell["attack"]
    metadata = {"attack": attack, "variant": cell.get("attack_variant"), "original_files": {}}
    if attack == "chat_inject":
        path = original / "chat_inject_attacks.py"
        load_file("spw_paper_chat_inject", path)
        metadata["original_files"][path.name] = sha(path)
        os.environ["CONRAC_CHATINJECT_MODEL_KEY"] = "qwen3"
    elif attack == "autodojo":
        path = original / "uv2x_hook.py"
        module = load_file("spw_paper_autodojo", path)  # UV2X_MODE is unset: import hook is inert.
        module.MODE = "autodojo"
        cache = root / "attacks/autodojo_cache" / cell["suite"] / "injections.json"
        os.environ.update(AUTODOJO_CACHE=str(cache), AUTODOJO_VARIANT="0", UV2X_STAMP=str(records / "attack_stamps.jsonl"))
        from agentdojo.attacks import attack_registry
        import agentdojo.attacks.base_attacks as base
        attack_registry.ATTACKS["autodojo"] = module._make_autodojo(base)
        metadata.update(cache_sha256=sha(cache), original_files={path.name: sha(path)})
    elif attack == "cache_injection":
        path = original / "rope_cache_injection.py"
        cache = root / "attacks/pismith_injections.json"
        require(cell.get("attack_variant") == 0, "PISmith scope is frozen variant 0 ASR@1")
        os.environ.update(UV2R_CACHE=str(cache), UV2R_ATTEMPT="0", UV2R_ARM="spwplus",
                          UV2R_STAMP=str(records / "attack_stamps.jsonl"))
        load_file("spw_paper_pismith_cache", path)
        metadata.update(cache_sha256=sha(cache), original_files={path.name: sha(path)})
    elif attack in {"direct", "system_message"}:
        # Only the metadata address changes; the original fixed payload has no
        # {model} token. Keep its text byte-identical to the official wheel.
        from agentdojo.attacks.base_attacks import FixedJailbreakAttack
        FixedJailbreakAttack.model_name = os.environ["CONRAC_INJ_MODEL_NAME"]
        metadata["fixed_attack_model_name"] = FixedJailbreakAttack.model_name
    else:
        require(attack in {"none", "important_instructions"}, "No verified adapter for attack: " + str(attack))
    if cell.get("source_mutation"):
        mutation = cell["source_mutation"]
        require(isinstance(mutation, str) and mutation in {"sender", "attacker_as_sender", "sender_fields_only"}
                or isinstance(mutation, dict) and mutation.get("kind") == "sender",
                "Unknown source mutation")
        require(cell["suite"] == "workspace", "Sender mutation is Workspace only")
        path = original / "uv2x_hook.py"
        module = load_file("spw_paper_sender", path)
        module.MODE = "sender"
        os.environ["UV2X_STAMP"] = str(records / "attack_stamps.jsonl")
        import agentdojo.task_suite.task_suite as task_suite
        module._patch_task_suite(task_suite)
        # Official 0.1.35 suites use TaskSuite. Existing overrides, if present,
        # receive the same outermost wrapper as future subclasses.
        def descendants(cls):
            for sub in cls.__subclasses__():
                yield sub
                yield from descendants(sub)
        for cls in descendants(task_suite.TaskSuite):
            own = cls.__dict__.get("load_and_inject_default_environment")
            if own is not None and not hasattr(own, "__wrapped__"):
                cls.load_and_inject_default_environment = module._wrap_loader(own)
        metadata.update(sender=module.ATTACKER, sender_original_sha256=sha(path))
    return metadata


def verify_output(records, cell):
    evidence = rows(Path(records) / "attack_stamps.jsonl")
    attack = cell["attack"]
    result = {"attack": attack, "stamp_rows": len(evidence), "verified": True}
    if attack == "autodojo":
        init = [r for r in evidence if r.get("event") == "autodojo_init"]
        actual = [r for r in evidence if r.get("event") == "autodojo_attack"]
        require(bool(init) and all(r["suite"] == cell["suite"] for r in init), "AutoDojo cache was not initialized")
        require(bool(actual) and all(r.get("fallback_goal") == 0 for r in actual), "AutoDojo fallback/missing payload detected")
    elif attack == "cache_injection":
        actual = [r for r in evidence if r.get("event") == "cache_attack"]
        require(bool(actual) and all(r.get("attempt") == 0 and r.get("n_variants") == 10
                                    and r.get("arm") == "spwplus" for r in actual), "PISmith variant/arm drift")
    if cell.get("source_mutation"):
        actual = [r for r in evidence if r.get("event") == "sender_patch"]
        require(bool(actual) and all(r.get("to") == "mark.black-2134@gmail.com"
                                    and set(map(str, r.get("emails", []))) == {"27", "28", "29", "31", "32"}
                                    for r in actual), "Exact sender mutation not observed")
    return result
