"""Final014 controller: inspection is metadata only; execution is explicit."""
from __future__ import annotations
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
import time
import uuid
from common import dump, planned, read, require, sha, positive


def inspect_packet(root):
    root = Path(root).resolve()
    files = read(root / "FILES.json")
    for name, digest in files.items():
        require(sha(root / name) == digest, "Packet drift: " + name)
    p = read(root / "PROTOCOL.json")
    require(p["artifact"]["version"] == "1.0.1" and p["execution_artifacts"] == ["final101"], "Only final014 execution is allowed")
    require(sha(root / p["artifact"]["wheel_file"]) == p["artifact"]["wheel_sha256"], "Final wheel bytes changed")
    return {"status": "BYTES_VERIFIED_NOT_EXECUTED", "wheel_sha256": p["artifact"]["wheel_sha256"],
            "source_manifest_sha256": p["artifact"]["source_manifest_sha256"],
            "inventory_protocol_sha256": p["inventory_protocol_sha256"], "scope": p["scope"],
            "planned_records": sum(len(planned(c)) for c in p["cells"]), "cells": len(p["cells"]),
            "dispatches": {name: {worker: sum(len(c["planned_uids"]) for c in cells)
                                 for worker, cells in group["workers"].items()} for name, group in p["dispatches"].items()},
            "semantic_gate": read(root / "SEMANTIC_GATE.json")["status"],
            "models_started": 0, "paid_API_calls": 0, "historical_metrics_replaced": False}


def validate_gate(p, gate):
    require(gate.get("status") == "PASS" and gate.get("blockers") == [] and gate.get("model_execution_allowed") is True,
            "Semantic gate blocked: " + ", ".join(gate.get("blockers", ["missing PASS"])))
    require(gate.get("wheel_sha256") == p["artifact"]["wheel_sha256"], "Gate wheel mismatch")
    require(gate.get("source_manifest_sha256") == p["artifact"]["source_manifest_sha256"], "Gate source mismatch")
    require(gate.get("protocol_sha256") == p["inventory_protocol_sha256"], "Gate inventory protocol mismatch")
    require(gate.get("profile_adopted_before_models") is True, "Profile adoption is missing")
    if "reference_manifest_sha256" in gate:
        require(gate["reference_manifest_sha256"] == p["artifact"]["reference_manifest_sha256"], "Gate reference mismatch")
    if "profiles" in gate:
        require(gate["profiles"] == p["profiles"], "Gate profile flags mismatch")


def execution_host(location):
    require(str(Path.home()) != "/Users/woosanglim", "Model/benchmark execution on the MacBook is forbidden")
    if location == "Colab":
        require(sys.platform == "linux" and Path("/content").is_dir(), "Colab Linux VM required")
    elif location == "Studio":
        require(str(Path.home()) == "/Users/woosang", "Explicit approved Studio user required")
    else:
        raise RuntimeError("execution_location must explicitly be Colab or Studio")


def require_live_ready(root, settings, host_check=True):
    inspect_packet(root)
    p = read(Path(root) / "PROTOCOL.json")
    require(settings.get("run_model") is True, "RUN_MODEL is False; metadata inspection only")
    gate_path = settings.get("root_gate_path")
    require(isinstance(gate_path, str) and gate_path, "New Root external execution gate required")
    gate = read(Path(gate_path))
    validate_gate(p, gate)
    require(gate.get("owner") == "root" and gate.get("root_reviewed") is True
            and gate.get("old_GO_reused") is False, "New Root artifact review missing")
    require(gate.get("packet_protocol_sha256") == sha(Path(root) / "PROTOCOL.json")
            and gate.get("packet_files_sha256") == sha(Path(root) / "FILES.json")
            and gate.get("authorization_sha256") == p["authorization_sha256"], "Root gate artifact mismatch")
    if host_check:
        execution_host(settings.get("execution_location"))
    dispatch = p["dispatches"].get(settings.get("dispatch"))
    require(dispatch is not None and str(settings.get("worker_id")) in dispatch["workers"], "Unknown dispatch/worker")
    if dispatch["kind"] == "paid":
        from provider_audit import require_paid_settings
        require_paid_settings(settings)
        require(positive(p.get("paid_hard_cap_usd")) and settings["hard_cap_usd"] <= p["paid_hard_cap_usd"],
                "Paid cap exceeds the frozen packet authorization")
        require(settings["prices"] == p.get("paid_prices"), "Paid prices differ from frozen verified packet prices")
        require(len(dispatch["workers"]) == 1, "Paid dispatch must use one runtime")
    return p


def resolve_paid_key(settings):
    # Return value is passed only in child environment, never serialized.
    if not settings.get("paid_api_opt_in"):
        raise RuntimeError("Paid API opt-in missing")
    key = os.environ.get("OPENAI_API_KEY")
    if settings.get("execution_location") == "Colab":
        try:
            from google.colab import userdata
            key = userdata.get("OPENAI_API_KEY")
        except Exception:
            key = None
    require(isinstance(key, str) and bool(key.strip()), "OPENAI_API_KEY absent; no provider call attempted")
    return key


def gpu_check(minimum_mib, expected_tokens=()):
    output = subprocess.check_output(["nvidia-smi", "--query-gpu=name,memory.total,memory.free,compute_cap,driver_version", "--format=csv,noheader,nounits"], text=True)
    lines = output.strip().splitlines()
    require(len(lines) == 1, "Exactly one CUDA GPU required")
    name, memory, free, capability, driver = [v.strip() for v in lines[0].split(",")]
    require(int(float(memory)) >= minimum_mib, "GPU below frozen memory floor")
    require(all(token.upper() in name.upper() for token in expected_tokens), "Requested RTX PRO6000 Blackwell GPU not allocated; no fallback")
    header = subprocess.check_output(["nvidia-smi"], text=True).splitlines()[:4]
    return {"name": name, "memory_MiB": int(float(memory)), "free_memory_MiB": int(float(free)),
            "compute_capability": capability, "driver_version": driver, "nvidia_smi_header": header,
            "backend": "Colab Linux CUDA; actual GPU identity above, not inferred from notebook preference"}


def install(root, drive_root, settings, *, progress=None):
    root, drive_root = Path(root).resolve(), Path(drive_root).resolve()
    p = require_live_ready(root, settings)
    require(settings["execution_location"] == "Colab", "Use explicit verified Studio environment, not Colab installer")
    dispatch = p["dispatches"][settings["dispatch"]]
    if dispatch["kind"] == "paid":
        resolve_paid_key(settings)  # fail before any install/model preparation
    gpu = gpu_check(dispatch.get("gpu_minimum_MiB", p["colab_gpu_minimum_MiB"]), p.get("colab_expected_gpu_tokens", []))
    from dependency_lock import measured_pins, record_environment
    pins, expected, provenance = measured_pins(root)
    state = Path("/content") / ("spw_final014_" + p["artifact"]["wheel_sha256"][:12])
    state.mkdir(exist_ok=True)
    venv = state / "venv"
    run_command = progress.run if progress is not None else subprocess.run
    if not (venv / "bin/python").exists():
        if progress is not None:
            progress.set_stage("evaluation_venv_create")
        run_command([sys.executable, "-m", "venv", str(venv)], check=True)
    python = str(venv / "bin/python")
    if progress is not None:
        progress.set_stage("dependencies_install_original_72", common_pins_sha256=sha(pins), count=72)
    # All 72 measured dependencies and the two SHA-verified local wheels are
    # explicit. No Drive lock or VM-local file URI is consumed as requirements.
    run_command([python, "-m", "pip", "install", "--disable-pip-version-check", "--no-deps",
                 "-r", str(pins)], check=True)
    # A reused venv otherwise retains the first packet\'s direct_url.json even
    # when identical-version wheel bytes are supplied from a new unpack root.
    # Refresh only the two local wheels; preserve all common pins/model caches.
    if progress is not None:
        progress.set_stage("local_wheels_refresh_current_packet", distributions=2)
    run_command([python, "-m", "pip", "install", "--disable-pip-version-check", "--no-deps",
                 "--force-reinstall", str(root / p["agentdojo"]["wheel_file"]),
                 str(root / p["artifact"]["wheel_file"])], check=True)
    if progress is not None:
        progress.set_stage("dependencies_pip_check")
    run_command([python, "-m", "pip", "check"], check=True)
    freeze = subprocess.check_output([python, "-m", "pip", "freeze"], text=True)
    dependency_receipt = record_environment(root, drive_root, settings, p, freeze)
    receipt = {"python": python, "state": str(state), "python_version": sys.version, "gpu": gpu,
               "pip_freeze": freeze, "pip_freeze_sha256": __import__("hashlib").sha256(freeze.encode()).hexdigest(),
               **dependency_receipt, "platform": platform.platform(),
               "local_wheels_refreshed_from_current_packet": True}
    dump(state / "INSTALL_RECEIPT.json", receipt)
    if progress is not None:
        progress.set_stage("dependencies_verified_original_72", common_pins_sha256=sha(pins))
    return receipt


def run_worker(root, drive_root, installed, server, settings):
    """Only one final014 worker may issue calls to a given endpoint at once."""
    import fcntl
    import hashlib
    require_live_ready(root, settings)
    lease_root = Path(tempfile.gettempdir()) / "spillway_final014_endpoint_owners"
    lease_root.mkdir(parents=True, exist_ok=True)
    key = hashlib.sha256(server["endpoint"].encode()).hexdigest()
    with (lease_root / (key + ".lock")).open("a+") as lock:
        try:
            fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            raise RuntimeError("An active final014 worker owns this endpoint; do not duplicate or unload it")
        owner = {"endpoint": server["endpoint"], "pid": os.getpid(), "run_id": settings.get("run_id"),
                 "dispatch": settings.get("dispatch"), "worker_id": settings.get("worker_id"),
                 "state": "ACTIVE", "model_unloading_permitted": False}
        dump(lease_root / (key + ".json"), owner)
        try:
            return _run_worker(root, drive_root, installed, server, settings)
        finally:
            dump(lease_root / (key + ".json"), {**owner, "state": "RELEASED"})
            fcntl.flock(lock, fcntl.LOCK_UN)


def _run_worker(root, drive_root, installed, server, settings):
    root, drive_root = Path(root).resolve(), Path(drive_root).resolve()
    p = require_live_ready(root, settings)
    dispatch = p["dispatches"][settings["dispatch"]]
    worker = str(settings["worker_id"])
    selected = dispatch["workers"][worker]
    state = Path(installed["state"])
    # One immutable run id is shared by the notebooks; each worker owns its
    # unique output. Never resume partial old files automatically.
    require(isinstance(settings.get("run_id"), str) and settings["run_id"] and "/" not in settings["run_id"], "Explicit run_id required")
    records = drive_root / "results" / settings["run_id"] / settings["dispatch"] / worker
    require(not records.exists(), "Worker output already exists; inspect its owner/partial data before any new run")
    records.mkdir(parents=True, exist_ok=False)
    local = state / "runs" / settings["run_id"] / settings["dispatch"] / worker
    local.mkdir(parents=True, exist_ok=False)
    key = {"settings": settings, "artifact": p["artifact"], "inventory_protocol_sha256": p["inventory_protocol_sha256"],
           "protocol_sha256": sha(root / "PROTOCOL.json"), "installed": installed, "server": server,
           "platform": settings["execution_location"], "planned_records": sum(len(c["planned_uids"]) for c in selected),
           "owner_nonce": uuid.uuid4().hex, "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
    dump(records / "RUN_KEY.json", key, exclusive=True)
    dump(local / "RUN_KEY.json", key, exclusive=True)
    settings_path = local / "SETTINGS.json"
    dump(settings_path, settings, exclusive=True)
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1", OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1")
    key["observed_PYTHONHASHSEED"] = env.get("PYTHONHASHSEED")
    dump(records / "RUN_KEY.json", key)
    dump(local / "RUN_KEY.json", key)
    if dispatch["kind"] == "paid":
        env["OPENAI_API_KEY"] = resolve_paid_key(settings)
    stages = []
    try:
        for cell in selected:
            # Raw episodes and per-call audits go directly to the mounted Drive
            # directory, rather than waiting for an entire suite to finish.
            path = records / "cells" / cell["cell_id"]
            path.mkdir(parents=True, exist_ok=False)
            spec = path / "CELL.json"
            dump(spec, cell, exclusive=True)
            command = [installed["python"], "-B", str(root / "measurement_worker_entry.py"), "--root", str(root), "--records", str(path),
                       "--study-records", str(local), "--settings", str(settings_path), "--cell", str(spec), "--endpoint", server["endpoint"]]
            with (path / "stdout.txt").open("x") as stdout, (path / "stderr.txt").open("x") as stderr:
                process = subprocess.run(command, env=env, stdout=stdout, stderr=stderr)
            stage = {"cell_id": cell["cell_id"], "returncode": process.returncode, "planned": len(cell["planned_uids"])}
            stages.append(stage)
            dump(local / "PROGRESS.json", {"status": "RUNNING", "stages": stages})
            shutil.copytree(local, records, dirs_exist_ok=True)
            require(process.returncode == 0 and (path / "CELL_CLOSURE.json").is_file(), "Cell failed; partial records remain unscored")
        dump(local / "WORKER_CLOSURE.json", {"status": "EXACT_UID_WORKER_COMPLETE", "worker_id": worker,
                                             "dispatch": settings["dispatch"], "stages": stages,
                                             "planned_records": key["planned_records"], "global_scope_complete": False})
    except BaseException as error:
        dump(local / "STOPPED.json", {"status": "STOPPED_PARTIAL_UNSCORED", "error_type": type(error).__name__, "stages": stages})
        raise
    finally:
        # Mirror all data even on cancellation/errors; no API key is in settings
        # or run key. If Drive fails, the local tree survives for recovery.
        shutil.copytree(local, records, dirs_exist_ok=True)
    return {"status": "EXACT_UID_WORKER_COMPLETE", "records": str(records), "global_scope_complete": False}
