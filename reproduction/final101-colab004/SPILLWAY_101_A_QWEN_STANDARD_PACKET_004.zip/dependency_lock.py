"""Portable measured pins; VM wheel paths are provenance, never requirements."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
from urllib.parse import parse_qs, unquote, urlsplit

from common import dump, require, sha


def _name(value):
    return re.sub(r"[-_.]+", "-", value).lower()


def measured_pins(root):
    root = Path(root).resolve()
    path = root / "dependencies/ORIGINAL_PY313_COMMON_72.txt"
    provenance = json.loads((root / "dependencies/ORIGINAL_PY313_COMMON_72.json").read_text())
    text = path.read_text()
    require(text.endswith("\n") and len(text.splitlines()) == 72,
            "Measured common closure must retain exactly 72 newline-terminated pins")
    require(sha(path) == provenance["common_72_sha256"], "Measured dependency pin bytes changed")
    names = []
    for line in text.splitlines():
        match = re.fullmatch(r"([A-Za-z0-9][A-Za-z0-9._-]*)==([^\s;@]+)", line)
        require(match is not None, "Common pins must contain versions only, never local paths")
        names.append(_name(match.group(1)))
    require(len(set(names)) == 72 and not {"agentdojo", "spillway-guard"}.intersection(names),
            "Local wheels must remain separate from the portable dependency closure")
    require(len(provenance["original_runs"]) == 5 and
            len({r["pip_freeze_sha256"] for r in provenance["original_runs"]}) == 1,
            "Five measured original freezes must agree")
    return path, text, provenance


def split_installed_freeze(root, protocol, freeze):
    """Validate both local wheel URIs and remove only those two distributions."""
    root = Path(root).resolve()
    expected = {
        "agentdojo": (root / protocol["agentdojo"]["wheel_file"], protocol["agentdojo"]["wheel_sha256"]),
        "spillway-guard": (root / protocol["artifact"]["wheel_file"], protocol["artifact"]["wheel_sha256"]),
    }
    local, common = {}, []
    for line in freeze.splitlines():
        match = re.match(r"^([A-Za-z0-9][A-Za-z0-9._-]*)(?:\s*@\s*|==)", line)
        require(match is not None, "Unrecognized pip freeze line")
        name = _name(match.group(1))
        if name not in expected:
            require(" @ " not in line, "Unexpected direct URL in common dependency closure")
            common.append(line)
            continue
        require(name not in local and " @ " in line, "Local wheel provenance is missing or duplicated")
        source = line.split(" @ ", 1)[1]
        parsed = urlsplit(source)
        wheel, digest = expected[name]
        require(parsed.scheme == "file" and parsed.netloc in ("", "localhost") and
                Path(unquote(parsed.path)).resolve() == wheel.resolve(),
                "Installed local wheel points outside this VM packet")
        require(parse_qs(parsed.fragment).get("sha256") == [digest] and sha(wheel) == digest,
                "Installed local wheel digest differs from the frozen packet")
        local[name] = {"pip_freeze_line": line, "file_uri": source,
                       "resolved_packet_path": str(wheel.resolve()), "wheel_sha256": digest}
    require(set(local) == set(expected), "Both pinned local wheel records are required")
    return "\n".join(common) + "\n", local


def record_environment(root, drive_root, settings, protocol, freeze):
    """Each dispatch owns its lock; all compare against the same packaged pins."""
    pins, expected, provenance = measured_pins(root)
    common, local = split_installed_freeze(root, protocol, freeze)
    require(common == expected, "Installed dependency closure differs from the measured original 72 pins")
    dispatch = settings["dispatch"]
    run_id = settings["run_id"]
    worker = str(settings["worker_id"])
    for value in (dispatch, run_id, worker):
        require(isinstance(value, str) and value and re.fullmatch(r"[A-Za-z0-9_.-]+", value),
                "Explicit safe run/dispatch/worker identity required")
    # Unique top-level folders avoid cross-VM creation of one shared Drive folder.
    folder = Path(drive_root).resolve() / ("environment_locks_003_" + dispatch) / run_id / ("worker_" + worker)
    folder.mkdir(parents=True, exist_ok=True)
    lock = folder / "python3.13.txt"
    try:
        with lock.open("x") as stream:
            stream.write(expected)
    except FileExistsError:
        require(lock.read_text() == expected, "Existing per-dispatch dependency receipt differs; preserve it")
    wheel_metadata = {"scope": "VM_LOCAL_WHEEL_PATH_PROVENANCE_NOT_PIP_REQUIREMENTS",
                      "packet_root": str(Path(root).resolve()), "dispatch": dispatch,
                      "run_id": run_id, "worker_id": worker, "wheels": local,
                      "common_72_sha256": sha(pins),
                      "original_pip_freeze_sha256": provenance["original_pip_freeze_sha256"]}
    metadata_path = folder / "LOCAL_WHEELS.json"
    if metadata_path.exists():
        require(json.loads(metadata_path.read_text()) == wheel_metadata,
                "Existing VM-local wheel provenance differs; preserve it")
    else:
        dump(metadata_path, wheel_metadata, exclusive=True)
    return {"common_dependencies_sha256": sha(lock), "common_pins_source": str(pins),
            "common_pins_count": 72, "common_lock_path": str(lock),
            "local_wheel_metadata_path": str(metadata_path),
            "original_pip_freeze_sha256": provenance["original_pip_freeze_sha256"],
            "cross_VM_local_paths_used_as_requirements": False,
            "common_lock_is_comparison_receipt_only": True}
