"""Read-only progress observation; never starts/retries/changes a model call."""
from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time


class ProgressObserver:
    def __init__(self, root, drive_root, owner_dir, settings, protocol, *, interval=10):
        self.root = Path(root).resolve()
        self.owner_dir = Path(owner_dir)
        self.settings = dict(settings)
        self.state = Path("/content") / ("spw_final014_" + protocol["artifact"]["wheel_sha256"][:12])
        self.records = Path(drive_root) / "results" / settings["run_id"] / settings["dispatch"] / str(settings["worker_id"])
        self.cells = protocol["dispatches"][settings["dispatch"]]["workers"][str(settings["worker_id"])]
        self.interval = interval
        self.stage = "preparing"
        self.stage_details = {}
        self.errors = []
        self.child = None
        self.stop = threading.Event()
        self.guard = threading.RLock()
        self.raw_cache = {}
        self.thread = None

    def _error(self, error):
        with self.guard:
            self.errors.append(type(error).__name__)
        print("[SPILLWAY observation warning] " + type(error).__name__, flush=True)

    def set_stage(self, stage, **details):
        with self.guard:
            self.stage, self.stage_details = stage, details
        print("[SPILLWAY stage] " + stage + " " + json.dumps(details, sort_keys=True), flush=True)

    def start(self):
        self.thread = threading.Thread(target=self._loop, name="spillway-observer", daemon=True)
        self.thread.start()

    def _file(self, path):
        try:
            info = path.stat()
            return {"path": str(path), "bytes": info.st_size, "mtime_ns": info.st_mtime_ns}
        except FileNotFoundError:
            return {"path": str(path), "bytes": 0, "present": False}

    def snapshot(self):
        with self.guard:
            stage, details, errors = self.stage, dict(self.stage_details), list(self.errors)
        watched = [self.state / "ollama-linux-amd64.tar.zst", self.state / "ollama.log"]
        watched.extend(sorted((self.state / "models/blobs").glob("sha256-*")))
        watched.extend(self.owner_dir / n for n in ("preparation_stdout.txt", "preparation_stderr.txt", "stdout.txt", "stderr.txt"))
        counts = {"planned_scored_UIDs": sum(len(c["planned_uids"]) for c in self.cells),
                  "closed_cells": 0, "closed_scored_UIDs": 0,
                  "saved_unclosed_scored_scope_UIDs": 0}
        for cell in self.cells:
            folder = self.records / "cells" / cell["cell_id"]
            watched.extend(folder / n for n in ("stdout.txt", "stderr.txt", "calls.jsonl", "provider_responses.jsonl"))
            expected = {(r["user_task_id"], r["injection_task_id"]) for r in cell["planned_uids"]}
            closure = folder / "CELL_CLOSURE.json"
            if closure.is_file():
                try:
                    value = json.loads(closure.read_text())
                    observed = {(r["user_task_id"], r["injection_task_id"]) for r in value.get("planned_uids", [])}
                    if value.get("status") == "EXACT_UID_CELL_COMPLETE" and observed == expected and value.get("score", {}).get("scored") == len(expected):
                        counts["closed_cells"] += 1
                        counts["closed_scored_UIDs"] += len(expected)
                        continue
                except (OSError, ValueError, KeyError, TypeError):
                    pass
            saved = set()
            for path in (folder / "raw").rglob("*.json"):
                try:
                    info = path.stat()
                    signature = (info.st_size, info.st_mtime_ns)
                    cached = self.raw_cache.get(str(path))
                    if cached is None or cached[0] != signature:
                        value = json.loads(path.read_text())
                        key = (value.get("user_task_id"), value.get("injection_task_id")) if isinstance(value, dict) else None
                        valid = isinstance(value, dict) and "messages" in value and isinstance(value.get("utility"), bool) and isinstance(value.get("security"), bool)
                        self.raw_cache[str(path)] = (signature, key if valid else None)
                    key = self.raw_cache[str(path)][1]
                    if key in expected:
                        saved.add(key)
                except (OSError, ValueError, KeyError, TypeError):
                    pass
            counts["saved_unclosed_scored_scope_UIDs"] += len(saved)
        return {"UTC": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
                "stage": stage, "details": details, "controller_pid": os.getpid(),
                "child_pid": self.child.pid if self.child is not None else None,
                "child_returncode": self.child.poll() if self.child is not None else None,
                "dispatch": self.settings["dispatch"], "run_id": self.settings["run_id"],
                "counts": counts, "files": [self._file(p) for p in watched],
                "observation_errors": errors, "partial_UIDs_are_scored": False,
                "observer_additional_model_or_health_API_calls": 0}

    def emit(self):
        try:
            value = self.snapshot()
            path = self.owner_dir / "PREPARATION_HEARTBEAT.json"
            temporary = path.with_name(path.name + ".tmp." + str(os.getpid()))
            temporary.write_text(json.dumps(value, indent=2) + "\n")
            temporary.replace(path)
            with (self.owner_dir / "OBSERVATION.jsonl").open("a") as stream:
                stream.write(json.dumps(value, separators=(",", ":")) + "\n")
            total = sum(f["bytes"] for f in value["files"])
            counts = value["counts"]
            print("[SPILLWAY heartbeat] " + value["stage"] +
                  f" | watched_bytes={total} | closed_cells={counts['closed_cells']}/{len(self.cells)}" +
                  f" | closed_UIDs={counts['closed_scored_UIDs']}/{counts['planned_scored_UIDs']}" +
                  f" | saved_unclosed_UIDs={counts['saved_unclosed_scored_scope_UIDs']}", flush=True)
        except Exception as error:
            self._error(error)

    def _loop(self):
        while not self.stop.is_set():
            self.emit()
            self.stop.wait(self.interval)

    def close(self):
        self.stop.set()
        if self.thread is not None:
            self.thread.join(timeout=2)
        # A slow Drive read must never delay/cancel the owned worker cleanup.
        if self.thread is None or not self.thread.is_alive():
            self.emit()

    def run(self, command, *, check=False, **kwargs):
        """Same argv/env/cwd and return-code policy; only tee preparation stdio."""
        process = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, **kwargs)

        def drain(stream, filename, console):
            log = None
            try:
                log = (self.owner_dir / filename).open("ab")
            except OSError as error:
                self._error(error)
            try:
                while True:
                    block = stream.read1(8192)
                    if not block:
                        break
                    if log is not None:
                        try:
                            log.write(block)
                            log.flush()
                        except OSError as error:
                            self._error(error)
                            log.close()
                            log = None
                    try:
                        console.write(block.decode("utf-8", errors="replace"))
                        console.flush()
                    except Exception as error:
                        self._error(error)
            finally:
                stream.close()
                if log is not None:
                    log.close()

        readers = [threading.Thread(target=drain, args=(process.stdout, "preparation_stdout.txt", sys.stdout), daemon=True),
                   threading.Thread(target=drain, args=(process.stderr, "preparation_stderr.txt", sys.stderr), daemon=True)]
        for reader in readers:
            reader.start()
        try:
            code = process.wait()
        except BaseException:
            process.terminate()
            try:
                process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                process.kill()
                process.wait()
            raise
        finally:
            for reader in readers:
                reader.join()
        if check and code:
            raise subprocess.CalledProcessError(code, command)
        return subprocess.CompletedProcess(command, code)
