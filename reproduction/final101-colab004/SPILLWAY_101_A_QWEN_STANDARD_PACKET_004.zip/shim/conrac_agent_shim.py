"""conrac_agent_shim v2.1 — hold the agent fixed across every runner of the unified v1.2.2 re-run.

Loaded in every runner process (Colab: a .pth line in the interpreter's site-packages; Studio: a sitecustomize.py in a
private directory placed first on PYTHONPATH). It wraps openai's chat.completions.create and is INERT unless
CONRAC_SHIM=1. When active, for the model families listed in CONRAC_SHIM_RULES (JSON, family -> request fields) it:

  1. system message: sent as role "system" (AgentDojo 0.1.35 sends "developer", which ollama's qwen3 and gpt-oss
     templates drop). The agent's prompt text becomes the published AgentDojo default (CONRAC_DEFAULT_PROMPT_FILE),
     keeping an allowed defense suffix (Spotlighting's delimiter instruction) when the caller composed one. Prompts that
     are not agent prompts (Progent's policy generator, ROPE's router, DRIFT's own prompt) keep their text; only the role
     is fixed.
  2. request fields from the family rule, e.g. {"reasoning_effort": "none"} (qwen3), {"reasoning_effort": "medium"}
     (gpt-oss), {"chat_template_kwargs": {"enable_thinking": false}} (gemma on mlx_lm). A reasoning_effort the caller sent
     is removed when the family rule does not set one (OpenAI gpt-4o-mini, gemma).
  3. decoding: max_completion_tokens is folded into max_tokens (ollama ignores it); max_tokens, temperature and seed are
     filled from CONRAC_MAX_TOKENS / CONRAC_TEMPERATURE / CONRAC_SEED when the caller sent none. A value the caller set
     explicitly is kept (e.g. Progent's policy calls: seed 0 and its temperature retry ladder).
  4. CONRAC_REQUEST_TIMEOUT: one per-request timeout for every client (infrastructure only).
  4b. context overflow, the OpenAI API's rule for every backbone (CONRAC_CONTEXT_WINDOW): a request whose prompt plus
     max_tokens exceeds the model's context window fails with BadRequestError code context_length_exceeded, so
     AgentDojo's own handler scores the pair (utility False, security True). OpenAI enforces this itself. ollama's /v1
     path instead drops the oldest messages and then cuts the token middle, silently (0.34.2 server/prompt.go chatPrompt,
     llm/llama_server.go L318), so for ollama (CONRAC_OLLAMA_PREFLIGHT = the native base URL) the shim first sends the
     same conversation to /api/chat with truncate:false and num_predict 1 (the reply's prompt_eval_count is the exact
     prompt length; a prompt longer than the context is an error there) and checks the /v1 reply's prompt_tokens equals
     it. MLX (gemma) does not truncate; its reply's prompt_tokens is checked after the call.
     One JSON line per call to CONRAC_CALL_LOG: family, the fields actually sent, finish_reason, usage (incl. cached
     tokens), hidden-reasoning length, the sha of the system text actually sent, latency, errors.
  5. spend guard for priced families (CONRAC_PRICE_JSON): cost per call appended to CONRAC_SPEND_FILE; when the running
     total reaches CONRAC_BUDGET_USD the next call raises before it is sent.
"""
import hashlib
import json
import os
import threading
import time

_LOCK = threading.Lock()
PROMPT_PREFIXES_AGENT = (
    "You are an AI language model who assists the user by using the given tools",       # AgentDojo / AgentDyn defaults
    "You are a helpful AI assistant. Always follow the user's instructions",              # ConRAC harness minimal prompt
)


def _family(model):
    m = str(model or "").lower()
    if m.startswith("gpt-oss"):
        return "gpt-oss"
    if "qwen3" in m and "qwen3.5" not in m:
        return "qwen3"
    if m.startswith(("gpt-4o", "gpt-4.1", "gpt-5", "o1", "o3", "o4")):
        return "openai"
    if "gemma-4" in m or m.startswith("gemma4"):
        return "gemma4"
    return None


def _sys_text(msgs):
    if not msgs or not isinstance(msgs, (list, tuple)) or not isinstance(msgs[0], dict):
        return None
    if msgs[0].get("role") not in ("system", "developer"):
        return None
    c = msgs[0].get("content")
    if isinstance(c, list):
        c = "".join((p.get("text") or p.get("content") or "") for p in c if isinstance(p, dict))
    return c


OLLAMA_OVERFLOW_TEXTS = ("exceeds the available context size", "exceed_context_size", "the prompt is longer than the context length")
OVERFLOW_TEXTS = ("context_length_exceeded", "maximum context length is exceeded")   # what the shim's own error carries


def to_ollama_messages(msgs):
    """OpenAI chat messages -> ollama api.Message dicts, mirroring ollama 0.34.2 openai.FromChatRequest
    (openai/openai.go L562-660): each text part of a list content becomes its own message; tool calls go on the last one;
    a tool message's tool_name is its name or the name of the call it answers. Pure function, unit-tested."""
    def tname(tcid):
        for m in reversed(msgs):
            for tc in (m.get("tool_calls") or []):
                if tc.get("id") == tcid:
                    return (tc.get("function") or {}).get("name") or ""
        return ""

    def tcs(m):
        out = []
        for tc in (m.get("tool_calls") or []):
            f = tc.get("function") or {}
            a = f.get("arguments")
            out.append({"id": tc.get("id"), "function": {"name": f.get("name"), "arguments": json.loads(a) if isinstance(a, str) and a else (a or {})}})
        return out

    res = []
    for m in msgs:
        role, content = m.get("role"), m.get("content")
        tool_name = ""
        if str(role).lower() == "tool":
            tool_name = m.get("name") or ""
            if not tool_name and m.get("tool_call_id"):
                tool_name = tname(m["tool_call_id"])
        extra = {}
        if m.get("reasoning"):
            extra["thinking"] = m["reasoning"]
        if isinstance(content, str):
            d = {"role": role, "content": content, **extra}
            if m.get("tool_calls"):
                d["tool_calls"] = tcs(m)
            if tool_name:
                d["tool_name"] = tool_name
            if m.get("tool_call_id"):
                d["tool_call_id"] = m["tool_call_id"]
            res.append(d)
        elif isinstance(content, (list, tuple)):
            for part in content:
                if not isinstance(part, dict) or part.get("type") != "text":
                    raise ValueError("preflight: only text parts are supported, got %r" % (part,))
                res.append({"role": role, "content": part.get("text") or ""})
            if res and m.get("tool_calls"):
                res[-1]["tool_calls"] = tcs(m)
                if tool_name:
                    res[-1]["tool_name"] = tool_name
                if m.get("tool_call_id"):
                    res[-1]["tool_call_id"] = m["tool_call_id"]
                res[-1].update(extra)
        else:
            d = {"role": role, **extra}
            if m.get("tool_calls"):
                d["tool_calls"] = tcs(m)
            if m.get("tool_call_id"):
                d["tool_call_id"] = m["tool_call_id"]
            res.append(d)
    return res


def ollama_think(effort):
    """reasoning_effort -> ollama think value (0.34.2 openai.thinkFromReasoningEffort)."""
    if not effort:
        return None
    return {"none": False, "minimal": "low", "xhigh": "max", "ultra": "max"}.get(effort, effort)


def rewrite_system(text, default_prompt, suffixes):
    """Return (new_text, label). Pure function, unit-tested."""
    if text is None:
        return None, "none"
    t = text.replace(" /no_think", "").replace("/no_think", "")
    if t == default_prompt:
        return default_prompt, "default"
    for name, suf in suffixes.items():
        if t == default_prompt + suf:
            return t, "default+" + name
    if t.lstrip().startswith(PROMPT_PREFIXES_AGENT):
        for name, suf in suffixes.items():                  # the caller's prompt carried a defense suffix: keep it
            if t.endswith(suf):
                return default_prompt + suf, "replaced+" + name
        return default_prompt, "replaced"
    return text, "kept (not an agent prompt)"


def _install():
    if os.environ.get("CONRAC_SHIM") != "1":
        return
    try:
        import importlib
        import openai
    except Exception:
        return
    comp = None
    for modname in ("openai.resources.chat.completions.completions", "openai.resources.chat.completions"):
        try:
            m = importlib.import_module(modname)
            if hasattr(m, "Completions"):
                comp = m
                break
        except Exception:
            continue
    if comp is None or getattr(comp.Completions, "_conrac_shim_v2", False):
        return
    NOT_GIVEN = openai.NOT_GIVEN
    # "not sent" sentinels across SDK versions: NotGiven (1.x-3.x) and Omit (3.x, the default of create()'s parameters)
    _SENT = tuple(t for t in (getattr(openai, "NotGiven", None), getattr(openai, "Omit", None)) if isinstance(t, type))
    orig = comp.Completions.create
    rules = json.loads(os.environ.get("CONRAC_SHIM_RULES", "{}"))
    prices = json.loads(os.environ.get("CONRAC_PRICE_JSON", "{}"))
    suffixes = json.loads(os.environ.get("CONRAC_PROMPT_SUFFIXES", "{}"))
    pf = os.environ.get("CONRAC_DEFAULT_PROMPT_FILE")
    default_prompt = open(pf, encoding="utf-8").read() if pf and os.path.exists(pf) else None
    unset = lambda v: v is None or v is NOT_GIVEN or (bool(_SENT) and isinstance(v, _SENT))

    def _spent():
        f = os.environ.get("CONRAC_SPEND_FILE")
        if not f or not os.path.exists(f):
            return 0.0
        try:
            return sum(float(l) for l in open(f) if l.strip())
        except Exception:
            return 0.0

    import urllib.request
    import urllib.error

    def _overflow(msg, param=None):
        """The OpenAI API's error for a request that does not fit, which AgentDojo's handler recognises
        (e.code == 'context_length_exceeded' or e.param == 'max_tokens' or 'reduce the length of the messages.')."""
        import httpx
        body = {"error": {"message": "This model's maximum context length is exceeded: %s. Please reduce the length of the messages." % msg,
                          "type": "invalid_request_error", "param": param, "code": "context_length_exceeded"}}
        r = httpx.Response(400, json=body, request=httpx.Request("POST", "http://conrac-shim/v1/chat/completions"))
        return openai.BadRequestError(body["error"]["message"], response=r, body=body["error"])

    def _preflight(base, kw, window):
        """Exact prompt length from ollama's native /api/chat (truncate:false, 1 token); raise the overflow error when the
        conversation does not fit or prompt + max_tokens exceeds the window."""
        opts = {"num_predict": 1, "temperature": kw.get("temperature"), "seed": kw.get("seed"), "top_p": 1.0}
        body = {"model": kw.get("model"), "messages": to_ollama_messages(list(kw.get("messages") or [])), "stream": False,
                "truncate": False, "options": {k: v for k, v in opts.items() if not unset(v)}}
        if not unset(kw.get("tools")):
            body["tools"] = kw["tools"]
        th = ollama_think(kw.get("reasoning_effort") if not unset(kw.get("reasoning_effort")) else None)
        if th is not None:
            body["think"] = th
        req = urllib.request.Request(base.rstrip("/") + "/api/chat", data=json.dumps(body).encode(), headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=float(os.environ.get("CONRAC_REQUEST_TIMEOUT") or 600)) as r:
                out = json.loads(r.read())
        except urllib.error.HTTPError as e:
            msg = e.read().decode("utf-8", "replace")[:300]
            low = msg.lower()
            # only ollama's own over-context refusals (0.34.2: llama-server "exceeds the available context size" /
            # exceed_context_size_error; llm/llama_server.go "the prompt is longer than the context length"); any other
            # HTTP error is a transport failure (the driver re-runs the user task), never a scored overflow
            if e.code in (400, 500) and any(t in low for t in OLLAMA_OVERFLOW_TEXTS):
                raise _overflow("ollama: %s" % msg)
            raise
        n = int(out.get("prompt_eval_count") or 0)
        mt = int(kw.get("max_tokens") or 0)
        if n + mt > window:
            raise _overflow("prompt %d + max_tokens %d > context window %d" % (n, mt, window), "max_tokens")
        return n

    def create(self, *a, **kw):
        model = kw.get("model")
        fam = _family(model)
        applied = {}
        msgs = kw.get("messages")
        role_in = msgs[0].get("role") if msgs and isinstance(msgs[0], dict) else None
        if fam in rules:
            # 1. system message
            st = _sys_text(msgs)
            if st is not None:
                new = st
                if default_prompt is not None and os.environ.get("CONRAC_FORCE_DEFAULT_PROMPT") == "1":
                    new, label = rewrite_system(st, default_prompt, suffixes)
                    applied["system_prompt"] = label
                msgs = list(msgs)
                msgs[0] = {"role": "system", "content": new}
                kw["messages"] = msgs
                if role_in != "system":
                    applied["role"] = "%s->system" % role_in
            # 2. family request fields
            for k, v in rules[fam].items():
                if isinstance(v, dict) and k in ("chat_template_kwargs",):
                    eb = dict(kw.get("extra_body") or {})
                    eb[k] = v
                    kw["extra_body"] = eb
                else:
                    kw[k] = v
                applied[k] = v
            if "reasoning_effort" not in rules[fam] and "reasoning_effort" in kw:
                # the family rule defines the reasoning control completely (OpenAI: none; gemma: chat_template_kwargs).
                # AgentDojo passes reasoning_effort=NOT_GIVEN on every call: drop it, record only a real value.
                _v = kw.pop("reasoning_effort")
                if not unset(_v):
                    applied["reasoning_effort_removed"] = _v
            # 3. decoding
            if not unset(kw.get("max_completion_tokens")):
                applied["max_completion_tokens_folded"] = kw.pop("max_completion_tokens")
                kw["max_tokens"] = int(os.environ.get("CONRAC_MAX_TOKENS", "8192"))
            if unset(kw.get("max_tokens")) and os.environ.get("CONRAC_MAX_TOKENS"):
                kw["max_tokens"] = int(os.environ["CONRAC_MAX_TOKENS"])
                applied["max_tokens"] = kw["max_tokens"]
            if unset(kw.get("temperature")) and os.environ.get("CONRAC_TEMPERATURE", "") != "":
                kw["temperature"] = float(os.environ["CONRAC_TEMPERATURE"])
                applied["temperature"] = kw["temperature"]
            if unset(kw.get("seed")) and os.environ.get("CONRAC_SEED"):
                kw["seed"] = int(os.environ["CONRAC_SEED"])
                applied["seed"] = kw["seed"]
            # 4. one request timeout for every client of every method (infrastructure, not decoding: a deterministic
            #    generation longer than a client's own short timeout would fail on every pass)
            if os.environ.get("CONRAC_REQUEST_TIMEOUT"):
                kw["timeout"] = float(os.environ["CONRAC_REQUEST_TIMEOUT"])
                applied["timeout"] = kw["timeout"]
        t0 = time.time()
        err = None
        resp = None
        window = int(os.environ.get("CONRAC_CONTEXT_WINDOW") or 0) if fam in rules else 0
        pre_url = os.environ.get("CONRAC_OLLAMA_PREFLIGHT") if fam in rules else None
        try:
            if window and pre_url:
                applied["preflight_prompt_tokens"] = _preflight(pre_url, kw, window)
            # 5. spend guard, before sending; inside the try so the refusal is logged like any other failed call
            budget = os.environ.get("CONRAC_BUDGET_USD")
            if fam in rules and fam in prices and budget and _spent() >= float(budget):
                raise RuntimeError("CONRAC spend guard: budget %s USD reached (%s)" % (budget, os.environ.get("CONRAC_SPEND_FILE")))
            resp = orig(self, *a, **kw)
            if window:
                pt = getattr(getattr(resp, "usage", None), "prompt_tokens", None)
                if pre_url and pt is not None and pt != applied.get("preflight_prompt_tokens"):
                    applied["preflight_mismatch"] = True      # audited: the preflight render differed from /v1's
                if pt is not None and pt + int(kw.get("max_tokens") or 0) > window:
                    raise _overflow("prompt %d + max_tokens %s > context window %d" % (pt, kw.get("max_tokens"), window), "max_tokens")
            return resp
        except Exception as e:
            err = repr(e)[:300]
            raise
        finally:
            log = os.environ.get("CONRAC_CALL_LOG")
            if log:
                rec = {"ts": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "model": model, "family": fam,
                       "latency_s": round(time.time() - t0, 3), "applied": applied, "role_in": role_in,
                       "n_messages": len(kw.get("messages") or []), "tag": os.environ.get("CONRAC_CALL_TAG"), "shim": "v2"}
                for k in ("temperature", "max_tokens", "seed", "reasoning_effort", "timeout"):
                    v = kw.get(k)
                    rec[k] = None if unset(v) else v
                rec["chat_template_kwargs"] = (kw.get("extra_body") or {}).get("chat_template_kwargs")
                st = _sys_text(kw.get("messages"))
                rec["system_sha256"] = hashlib.sha256(st.encode()).hexdigest()[:16] if st is not None else None
                if err:
                    rec["error"] = err
                if resp is not None:
                    try:
                        ch = resp.choices[0]
                        m = ch.message
                        extra = getattr(m, "model_extra", None) or {}
                        reasoning = extra.get("reasoning") or extra.get("reasoning_content") or ""
                        u = getattr(resp, "usage", None)
                        det = getattr(u, "prompt_tokens_details", None)
                        cached = getattr(det, "cached_tokens", None) if det is not None else None
                        rec.update({"finish_reason": ch.finish_reason, "prompt_tokens": getattr(u, "prompt_tokens", None),
                                    "completion_tokens": getattr(u, "completion_tokens", None), "cached_tokens": cached,
                                    "content_len": len(m.content or ""), "reasoning_len": len(reasoning),
                                    "n_tool_calls": len(m.tool_calls or []), "system_fingerprint": getattr(resp, "system_fingerprint", None)})
                        if fam in prices and u is not None:
                            p = prices[fam]
                            pt = rec["prompt_tokens"] or 0
                            ct = cached or 0
                            cost = ((pt - ct) * p["input"] + ct * p["cached_input"] + (rec["completion_tokens"] or 0) * p["output"]) / 1e6
                            rec["cost_usd"] = round(cost, 6)
                            sf = os.environ.get("CONRAC_SPEND_FILE")
                            if sf:
                                with _LOCK, open(sf, "a") as fh:
                                    fh.write("%.8f\n" % cost)
                    except Exception as e:
                        rec["log_error"] = repr(e)[:200]
                try:
                    line = json.dumps(rec, default=repr)          # an unexpected object is written as its repr, never drops the line
                except Exception as e:
                    line = json.dumps({"ts": rec.get("ts"), "model": str(model), "family": fam, "tag": rec.get("tag"), "shim": "v2", "log_error": repr(e)[:200]})
                try:
                    with _LOCK, open(log, "a", encoding="utf-8") as fh:
                        fh.write(line + "\n")
                except Exception as e:
                    import sys
                    print("[conrac_agent_shim] call-log write failed: %r" % (e,), file=sys.stderr)

    comp.Completions.create = create
    comp.Completions._conrac_shim_v2 = True


_install()
